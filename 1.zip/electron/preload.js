const { contextBridge, ipcRenderer } = require('electron');

// Expose APIs to renderer process
contextBridge.exposeInMainWorld('electron', {
  // Platform info
  platform: process.platform,
  
  // Shell operations - FIX: Dùng IPC thay vì direct shell
  shell: {
    openExternal: (url) => ipcRenderer.invoke('open-external', url),
  },

  // IPC Communication
  ipcRenderer: {
    invoke: (channel, data) => ipcRenderer.invoke(channel, data),
    send: (channel, data) => ipcRenderer.send(channel, data),
    on: (channel, callback) => {
      ipcRenderer.on(channel, (event, ...args) => callback(...args));
    },
    removeAllListeners: (channel) => {
      ipcRenderer.removeAllListeners(channel);
    },
  },

  // Notifications
  showNotification: (options) => {
    ipcRenderer.send('show-notification', options);
  },

  // Hotkey management
  registerHotkey: (accelerator, callback) => {
    const id = `hotkey-${Date.now()}-${Math.random()}`;
    ipcRenderer.send('register-hotkey', { id, accelerator });
    ipcRenderer.on(`hotkey-pressed-${id}`, callback);
    return id;
  },

  unregisterHotkey: (id) => {
    ipcRenderer.send('unregister-hotkey', id);
    ipcRenderer.removeAllListeners(`hotkey-pressed-${id}`);
  },

  unregisterAllHotkeys: () => {
    ipcRenderer.send('unregister-all-hotkeys');
  },

  // App version
  getAppVersion: () => ipcRenderer.invoke('get-app-version'),

  // Minimize to tray
  minimizeToTray: () => ipcRenderer.send('minimize-to-tray'),

  // Auto-updater events
  onUpdateAvailable: (callback) => {
    ipcRenderer.on('update-available', callback);
  },

  onUpdateDownloaded: (callback) => {
    ipcRenderer.on('update-downloaded', callback);
  },

  // Focus search (for global shortcut)
  onFocusSearch: (callback) => {
    ipcRenderer.on('focus-search', callback);
  },

  // Lock app (for global shortcut)
  onLockApp: (callback) => {
    ipcRenderer.on('lock-app', callback);
  },
  autoType: (username, password, delay) => 
    ipcRenderer.invoke('auto-type', { username, password, delay }),
});

console.log('🔌 Preload script loaded successfully');
console.log('📱 Platform:', process.platform);
console.log('✅ Electron APIs exposed to window.electron');