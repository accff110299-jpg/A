import { app, BrowserWindow, ipcMain, globalShortcut, Menu, Tray, Notification, shell } from 'electron';
import path from 'path';
import { fileURLToPath } from 'url';
import robot from 'robotjs';


const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let mainWindow = null;
let tray = null;
const registeredHotkeys = new Map();



// Disable hardware acceleration for better compatibility
app.disableHardwareAcceleration();

/**
 * Create main application window
 */
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    minWidth: 800,
    minHeight: 600,
    frame: true,
    titleBarStyle: 'default',
    backgroundColor: '#ffffff',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
      webSecurity: true,
    },
    show: false,
  });

  // Load app
  if (process.env.NODE_ENV === 'development') {
    mainWindow.loadURL('http://localhost:5173');
    mainWindow.webContents.openDevTools();
  } else {
    mainWindow.loadFile(path.join(__dirname, '../dist/index.html'));
  }

  // Show window when ready
  mainWindow.once('ready-to-show', () => {
    mainWindow?.show();
  });

  // Handle window close
  mainWindow.on('close', (event) => {
    if (!app.isQuitting && process.platform !== 'darwin') {
      event.preventDefault();
      mainWindow?.hide();
    }
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
    unregisterAllHotkeys();
  });
}

/**
 * Create system tray
 */
function createTray() {
  const iconPath = path.join(__dirname, '../build/icon.png');
  
  try {
    tray = new Tray(iconPath);
    
    const contextMenu = Menu.buildFromTemplate([
      {
        label: 'Show App',
        click: () => mainWindow?.show(),
      },
      { type: 'separator' },
      {
        label: 'Quick Launch',
        submenu: [
          {
            label: 'Last Used Account',
            click: () => mainWindow?.webContents.send('quick-launch-last'),
          },
          {
            label: 'Favorite Account',
            click: () => mainWindow?.webContents.send('quick-launch-favorite'),
          },
        ],
      },
      { type: 'separator' },
      {
        label: 'Lock App',
        click: () => mainWindow?.webContents.send('lock-app'),
      },
      {
        label: 'Quit',
        click: () => {
          app.isQuitting = true;
          app.quit();
        },
      },
    ]);

    tray.setContextMenu(contextMenu);
    tray.setToolTip('Game Account Manager');

    tray.on('click', () => mainWindow?.show());
  } catch (error) {
    console.error('Failed to create tray:', error);
  }
}

/**
 * Register global shortcuts
 */
function registerShortcuts() {
  // Quick launch - Ctrl+Shift+L
  globalShortcut.register('CommandOrControl+Shift+L', () => {
    if (mainWindow) {
      if (mainWindow.isVisible()) {
        mainWindow.hide();
      } else {
        mainWindow.show();
      }
    }
  });

  // Quick search - Ctrl+K
  globalShortcut.register('CommandOrControl+K', () => {
    if (mainWindow) {
      mainWindow.show();
      mainWindow.webContents.send('focus-search');
    }
  });

  // Lock app - Ctrl+L
  globalShortcut.register('CommandOrControl+L', () => {
    mainWindow?.webContents.send('lock-app');
  });
}

/**
 * Register custom hotkey from renderer
 */
function registerCustomHotkey(id, accelerator) {
  try {
    const ret = globalShortcut.register(accelerator, () => {
      mainWindow?.webContents.send(`hotkey-pressed-${id}`);
    });

    if (ret) {
      registeredHotkeys.set(id, accelerator);
      return true;
    }
    return false;
  } catch (error) {
    console.error('Failed to register hotkey:', error);
    return false;
  }
}

/**
 * Unregister custom hotkey
 */
function unregisterCustomHotkey(id) {
  const accelerator = registeredHotkeys.get(id);
  if (accelerator) {
    globalShortcut.unregister(accelerator);
    registeredHotkeys.delete(id);
  }
}

/**
 * Unregister all custom hotkeys
 */
function unregisterAllHotkeys() {
  registeredHotkeys.forEach((accelerator) => {
    globalShortcut.unregister(accelerator);
  });
  registeredHotkeys.clear();
}

/**
 * App ready
 */
app.whenReady().then(() => {
  createWindow();
  createTray();
  registerShortcuts();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

/**
 * Quit when all windows are closed
 */
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

/**
 * Cleanup before quit
 */
app.on('will-quit', () => {
  globalShortcut.unregisterAll();
  unregisterAllHotkeys();
});

/**
 * IPC Handlers
 */

// Get app version
ipcMain.handle('get-app-version', () => {
  return app.getVersion();
});

// Get platform
ipcMain.handle('get-platform', () => {
  return process.platform;
});

// Minimize to tray
ipcMain.on('minimize-to-tray', () => {
  mainWindow?.hide();
});

// Show notification
ipcMain.on('show-notification', (event, { title, body }) => {
  if (Notification.isSupported()) {
    new Notification({
      title,
      body,
      icon: path.join(__dirname, '../build/icon.png'),
    }).show();
  }
});

// Open external link
// Open external link - FIX: Dùng handle thay vì on
ipcMain.handle('open-external', async (event, url) => {
  
  try {
    await shell.openExternal(url);
    return { success: true };
  } catch (error) {
    console.error('Failed to open external:', error);
    return { success: false, error: error.message };
  }
});

// Register hotkey
ipcMain.on('register-hotkey', (event, { id, accelerator }) => {
  const success = registerCustomHotkey(id, accelerator);
  event.reply('hotkey-registered', { id, success });
});

// Unregister hotkey
ipcMain.on('unregister-hotkey', (event, id) => {
  unregisterCustomHotkey(id);
});

// Unregister all hotkeys
ipcMain.on('unregister-all-hotkeys', () => {
  unregisterAllHotkeys();
});
// Thêm vào phần IPC Handlers (sau dòng 152 trong file main.js hiện tại)

// Focus window - THÊM CÁI NÀY
ipcMain.handle('focus-window', async () => {
  try {
    if (mainWindow) {
      if (mainWindow.isMinimized()) {
        mainWindow.restore();
      }
      mainWindow.focus();
      mainWindow.show();
      return { success: true };
    }
    return { success: false, error: 'Window not found' };
  } catch (error) {
    console.error('Failed to focus window:', error);
    return { success: false, error: error.message };
  }
});

/**
 * Security: Prevent navigation to external URLs
 */
app.on('web-contents-created', (event, contents) => {
  contents.on('will-navigate', (event, navigationUrl) => {
    const parsedUrl = new URL(navigationUrl);
    
    if (process.env.NODE_ENV === 'development') {
      if (parsedUrl.origin !== 'http://localhost:5173') {
        event.preventDefault();
      }
    } else {
      event.preventDefault();
    }
  });

  contents.setWindowOpenHandler(() => {
    return { action: 'deny' };
  });
});
ipcMain.handle('focus-window', async () => {
  try {
    if (mainWindow) {
      if (mainWindow.isMinimized()) {
        mainWindow.restore();
      }
      mainWindow.focus();
      mainWindow.show();
      mainWindow.setAlwaysOnTop(true);
      setTimeout(() => mainWindow.setAlwaysOnTop(false), 100);
      return { success: true };
    }
    return { success: false, error: 'Window not found' };
  } catch (error) {
    console.error('Failed to focus window:', error);
    return { success: false, error: error.message };
  }
});

// Auto-type handler với keysender
ipcMain.handle('auto-type', async (event, { username, password, delay = 800 }) => {
  try {
    console.log('🤖 Starting auto-type with robotjs...');
    
    await new Promise(r => setTimeout(r, delay));
    
    console.log('⌨️ Typing username:', username);
    robot.typeString(username);
    await new Promise(r => setTimeout(r, 600));
    
    console.log('⌨️ Pressing Tab...');
    robot.keyTap('tab');
    await new Promise(r => setTimeout(r, 1000));
    
    console.log('⌨️ Typing password...');
    robot.typeString(password);
    await new Promise(r => setTimeout(r, 600));
    
    console.log('⌨️ Pressing Enter...');
    robot.keyTap('enter');
    
    console.log('✅ Auto-type complete!');
    return { success: true };
  } catch (error) {
    console.error('❌ Auto-type failed:', error);
    return { success: false, error: error.message };
  }
});
/**
 * Error handling
 */
process.on('uncaughtException', (error) => {
  console.error('Uncaught exception:', error);
});

process.on('unhandledRejection', (error) => {
  console.error('Unhandled rejection:', error);
});