/**
 * Service quản lý lưu trữ dữ liệu local
 * Sử dụng localStorage thay vì electron-store để tương thích tốt hơn
 */
export class StorageService {
  constructor() {
    this.storageKey = 'gam-data';
    this.initializeStorage();
  }

  /**
   * Initialize storage with defaults if empty
   */
  initializeStorage() {
    if (!localStorage.getItem(this.storageKey)) {
      this.saveStore({
        accounts: [],
        groups: [],
        games: [], // Thêm games vào init
        settings: this.getDefaultSettings(),
        masterPasswordHash: '',
        activityLog: [],
      });
    } else {
      // Nếu đã có store nhưng thiếu games thì thêm vào
      this.ensureGamesExist();
    }
  }

  /**
   * Get entire store
   */
  getStore() {
    try {
      const data = localStorage.getItem(this.storageKey);
      return data ? JSON.parse(data) : this.getDefaultStore();
    } catch (error) {
      console.error('Failed to parse store:', error);
      return this.getDefaultStore();
    }
  }

  /**
   * Save entire store
   */
  saveStore(data) {
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(data));
    } catch (error) {
      console.error('Failed to save store:', error);
    }
  }

  /**
   * Get default store structure
   */
  getDefaultStore() {
    return {
      accounts: [],
      groups: [],
      games: [], // Thêm games
      settings: this.getDefaultSettings(),
      masterPasswordHash: '',
      activityLog: [],
    };
  }

  /**
   * Default settings
   */
  getDefaultSettings() {
    return {
      theme: 'system',
      language: 'en',
      autoLock: true,
      autoLockTimeout: 15,
      showNotifications: true,
      minimizeToTray: true,
      startMinimized: false,
      checkUpdates: true,
      hotkeys: {
        quickLaunch: 'CommandOrControl+Shift+L',
        quickSearch: 'CommandOrControl+K',
        newAccount: 'CommandOrControl+N',
        lock: 'CommandOrControl+L',
      },
      defaultView: 'grid',
      cloudSyncEnabled: false,
    };
  }

  // ==================== ACCOUNTS ====================

  getAccounts() {
    const store = this.getStore();
    return store.accounts || [];
  }

  saveAccounts(accounts) {
    const store = this.getStore();
    store.accounts = accounts;
    this.saveStore(store);
  }

  getAccountById(id) {
    const accounts = this.getAccounts();
    return accounts.find((acc) => acc.id === id);
  }

  addAccount(account) {
    const accounts = this.getAccounts();
    accounts.push(account);
    this.saveAccounts(accounts);
    
    this.addActivityLog({
      type: 'create',
      accountId: account.id,
      accountName: account.name,
      message: `Created account: ${account.name}`,
      severity: 'info',
    });
  }

  updateAccount(id, updates) {
    const accounts = this.getAccounts();
    const index = accounts.findIndex((acc) => acc.id === id);
    
    if (index !== -1) {
      accounts[index] = { ...accounts[index], ...updates };
      this.saveAccounts(accounts);
      
      this.addActivityLog({
        type: 'update',
        accountId: id,
        accountName: accounts[index].name,
        message: `Updated account: ${accounts[index].name}`,
        severity: 'info',
      });
    }
  }

  deleteAccount(id) {
    const accounts = this.getAccounts();
    const account = accounts.find((acc) => acc.id === id);
    const filtered = accounts.filter((acc) => acc.id !== id);
    this.saveAccounts(filtered);
    
    if (account) {
      this.addActivityLog({
        type: 'delete',
        accountId: id,
        accountName: account.name,
        message: `Deleted account: ${account.name}`,
        severity: 'warning',
      });
    }
  }

  // ==================== GROUPS ====================

  getGroups() {
    const store = this.getStore();
    return store.groups || [];
  }

  saveGroups(groups) {
    const store = this.getStore();
    store.groups = groups;
    this.saveStore(store);
  }

  addGroup(group) {
    const groups = this.getGroups();
    groups.push(group);
    this.saveGroups(groups);
  }

  updateGroup(id, updates) {
    const groups = this.getGroups();
    const index = groups.findIndex((g) => g.id === id);
    
    if (index !== -1) {
      groups[index] = { ...groups[index], ...updates };
      this.saveGroups(groups);
    }
  }

  deleteGroup(id) {
    const groups = this.getGroups();
    const filtered = groups.filter((g) => g.id !== id);
    this.saveGroups(filtered);
  }

  // ==================== GAMES ====================

  getGames() {
    const store = this.getStore();
    return store.games || [];
  }

  saveGames(games) {
    const store = this.getStore();
    store.games = games;
    this.saveStore(store);
  }

  addGame(game) {
    const games = this.getGames();
    games.push(game);
    this.saveGames(games);
  }

  ensureGamesExist() {
    const store = this.getStore();
    if (!Array.isArray(store.games)) {
      store.games = [];
      this.saveStore(store);
    }
  }

  // ==================== SETTINGS ====================

  getSettings() {
    const store = this.getStore();
    return store.settings || this.getDefaultSettings();
  }

  updateSettings(updates) {
    const store = this.getStore();
    store.settings = { ...store.settings, ...updates };
    this.saveStore(store);
  }

  resetSettings() {
    const store = this.getStore();
    store.settings = this.getDefaultSettings();
    this.saveStore(store);
  }

  // ==================== MASTER PASSWORD ====================

  saveMasterPasswordHash(hash) {
    const store = this.getStore();
    store.masterPasswordHash = hash;
    this.saveStore(store);
  }

  setMasterPasswordHash(hash) {
    this.saveMasterPasswordHash(hash);
  }

  getMasterPasswordHash() {
    const store = this.getStore();
    return store.masterPasswordHash || '';
  }

  hasMasterPassword() {
    return !!this.getMasterPasswordHash();
  }

  // ==================== ACTIVITY LOG ====================

  addActivityLog(entry) {
    const store = this.getStore();
    const logs = store.activityLog || [];
    const newEntry = {
      ...entry,
      id: Date.now().toString(),
      timestamp: Date.now(),
    };
    
    logs.unshift(newEntry);
    
    // Keep max 1000 logs
    if (logs.length > 1000) {
      logs.splice(1000);
    }
    
    store.activityLog = logs;
    this.saveStore(store);
  }

  getActivityLog(limit) {
    const store = this.getStore();
    const logs = store.activityLog || [];
    return limit ? logs.slice(0, limit) : logs;
  }

  clearActivityLog() {
    const store = this.getStore();
    store.activityLog = [];
    this.saveStore(store);
  }

  // ==================== BACKUP & RESTORE ====================

  backupData() {
    const store = this.getStore();
    store.lastBackup = Date.now();
    this.saveStore(store);
    
    return {
      accounts: store.accounts,
      groups: store.groups,
      games: store.games,
      settings: store.settings,
    };
  }

  restoreData(data) {
    const store = this.getStore();
    
    if (data.accounts) {
      store.accounts = data.accounts;
    }
    if (data.groups) {
      store.groups = data.groups;
    }
    if (data.games) {
      store.games = data.games;
    }
    if (data.settings) {
      store.settings = { ...store.settings, ...data.settings };
    }
    
    this.saveStore(store);
    
    this.addActivityLog({
      type: 'import',
      message: 'Data restored from backup',
      severity: 'info',
    });
  }

  getLastBackupTime() {
    const store = this.getStore();
    return store.lastBackup;
  }

  // ==================== UTILITIES ====================

  clearAll() {
    localStorage.removeItem(this.storageKey);
    this.initializeStorage();
  }

  getStorePath() {
    return 'localStorage';
  }

  getStoreSize() {
    try {
      const data = localStorage.getItem(this.storageKey);
      return data ? new Blob([data]).size : 0;
    } catch {
      return 0;
    }
  }
}