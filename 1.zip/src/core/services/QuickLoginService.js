/**
 * QuickLoginService.js - FULL FILE với Auto-Type
 * Copy paste toàn bộ file này vào: src/core/services/QuickLoginService.js
 */

export class QuickLoginService {
  constructor() {
    this.isElectron = typeof window !== 'undefined' && window.electron;
    this.clipboardHistory = [];
    this.activeHotkeys = new Set();
  }

  /**
   * METHOD 1: Sequential Copy (Safest)
   */
  async sequentialCopy(username, password, gameUrl = null) {
    try {
      await this.copyToClipboard(username);
      this.showNotification('Step 1/3', 'Username copied! Paste it now.');

      await this.sleep(3000);
      await this.copyToClipboard(password);
      this.showNotification('Step 2/3', 'Password copied! Paste it now.');

      if (gameUrl) {
        await this.sleep(2000);
        await this.launchGame(gameUrl);
        this.showNotification('Step 3/3', 'Game launched!');
      }

      return { success: true };
    } catch (error) {
      console.error('Sequential copy failed:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * METHOD 2: Two-Click Login
   */
  async twoClickLogin(username, password, gameUrl = null) {
    const clickCount = this.getClickCount() || 0;

    if (clickCount === 0) {
      await this.copyToClipboard(username);
      this.showNotification('Click 1/2', 'Username copied! Paste it, then click again for password.');
      
      if (gameUrl) {
        await this.sleep(500);
        await this.launchGame(gameUrl);
      }

      this.setClickCount(1);
      return { success: true, needSecondClick: true };
    } else {
      await this.copyToClipboard(password);
      this.showNotification('Click 2/2 Complete', 'Password copied! Login now!');
      this.setClickCount(0);
      return { success: true, needSecondClick: false };
    }
  }

  /**
   * METHOD 3: Smart Launch - AUTO COPY với DELAY CAO
   */
  async smartLaunch(username, password, gameUrl, options = {}) {
    const {
      usernameDelay = 1000,      // 1 giây
      passwordDelay = 18000,     // 18 GIÂY - delay CAO cho máy yếu
      launchDelay = 3000,        // 3 giây
    } = options;

    try {
      // Step 1: Focus và copy username
      if (this.isElectron) {
        try {
          await window.electron.ipcRenderer.invoke('focus-window');
          console.log('✅ Window focused via IPC');
        } catch (err) {
          console.warn('⚠️ IPC focus failed:', err);
        }
      }
      
      await this.sleep(500);
      window.focus();
      
      await this.sleep(usernameDelay);
      const usernameCopied = await this.copyToClipboard(username);
      
      if (usernameCopied) {
        this.showNotification('🎮 Step 1/3', 'Username copied! Paste it (Ctrl+V)');
      }

      // Step 2: Launch game
      if (gameUrl) {
        await this.sleep(launchDelay);
        const launched = await this.launchGame(gameUrl);
        
        if (launched.success) {
          const seconds = Math.floor(passwordDelay / 1000);
          this.showNotification(
            '🚀 Step 2/3', 
            `Game launched! Password auto-copy in ${seconds} seconds...`,
            { duration: 6000 }
          );
        }
      }

      // Step 3: Countdown
      const countdownStart = passwordDelay - 5000;
      await this.sleep(countdownStart);
      
      for (let i = 5; i > 0; i--) {
        this.showToast(
          '⏰ Password Coming...',
          `Password will be copied in ${i} seconds. Be ready to paste!`,
          'warning',
          900
        );
        await this.sleep(1000);
      }

      // Step 4: Copy password
      if (this.isElectron) {
        try {
          await window.electron.ipcRenderer.invoke('focus-window');
          console.log('✅ Window re-focused for password');
          await this.sleep(800);
        } catch (err) {
          console.warn('⚠️ IPC re-focus failed:', err);
        }
      }
      
      window.focus();
      document.body.focus();
      await this.sleep(500);
      
      const passwordCopied = await this.copyToClipboard(password);
      
      if (passwordCopied) {
        this.showNotification(
          '🔑 Step 3/3', 
          'PASSWORD COPIED! Press Ctrl+V NOW!',
          { duration: 10000 }
        );
        this.playAlertSound();
      }

      setTimeout(async () => {
        try {
          await this.copyToClipboard('');
        } catch (e) {}
      }, 30000);

      return { success: true };
    } catch (error) {
      console.error('Smart launch failed:', error);
      this.showToast('❌ Smart Launch Failed', error.message, 'error', 3000);
      return { success: false, error: error.message };
    }
  }

  /**
   * METHOD 4: Auto-Type - TỰ ĐỘNG GÕ PHÍM
   */
  async autoType(username, password, gameUrl, options = {}) {
    const {
      launchDelay = 3000,
      formDelay = 18000,         // 18 GIÂY đợi form load
      countdownSeconds = 5,
      typingDelay = 800,         // Delay giữa các lần gõ
    } = options;

    try {
      // Step 1: Launch game
      if (gameUrl) {
        this.showNotification('🚀 Step 1/4', 'Launching game...');
        await this.launchGame(gameUrl);
        await this.sleep(launchDelay);
      }

      // Step 2: Đợi game load với progress
      const loadSeconds = Math.floor(formDelay / 1000);
      this.showToast(
        '⏳ Step 2/4 - Loading',
        `Waiting ${loadSeconds} seconds for game to load...`,
        'info',
        5000
      );
      
      // Show progress every 3 seconds
      const progressInterval = 3000;
      const steps = Math.floor(formDelay / progressInterval);
      
      for (let i = 1; i <= steps; i++) {
        await this.sleep(progressInterval);
        const remaining = loadSeconds - (i * 3);
        if (remaining > 0) {
          this.showToast(
            '⏳ Still Loading...',
            `${remaining} seconds remaining...`,
            'info',
            2000
          );
        }
      }
      
      // Đợi phần còn lại
      const remainingTime = formDelay % progressInterval;
      if (remainingTime > 0) {
        await this.sleep(remainingTime);
      }

      // Step 3: Countdown
      this.showToast(
        '🎯 Step 3/4 - IMPORTANT!',
        'CLICK on the USERNAME field RIGHT NOW!',
        'warning',
        3000
      );
      
      for (let i = countdownSeconds; i > 0; i--) {
        this.showToast(
          '⌨️ Auto-Type Starting...',
          `Make sure your cursor is in the USERNAME field! Starting in ${i}...`,
          'warning',
          900
        );
        this.playAlertSound();
        await this.sleep(1000);
      }

      // Step 4: AUTO-TYPE
      if (this.isElectron && window.electron.autoType) {
        this.showNotification('⌨️ Step 4/4', 'Auto-typing credentials now...');
        
        const result = await window.electron.autoType(username, password, typingDelay);
        
        if (result.success) {
          this.showNotification('✅ SUCCESS!', 'Login credentials submitted!');
          this.playAlertSound();
          this.playAlertSound(); // Double beep
          return { success: true };
        } else {
          throw new Error(result.error);
        }
      } else {
        throw new Error('Auto-type only works in Electron app');
      }
    } catch (error) {
      console.error('Auto-type failed:', error);
      this.showToast('❌ Auto-Type Failed', error.message, 'error', 5000);
      return { success: false, error: error.message };
    }
  }

  /**
   * Copy to clipboard
   */
  async copyToClipboard(text) {
    try {
      await navigator.clipboard.writeText(text);
      console.log('✅ Clipboard API success');
      return true;
    } catch (error) {
      console.warn('⚠️ Clipboard API failed:', error.message);
      return this.copyWithExecCommand(text);
    }
  }

  /**
   * Fallback copy
   */
  copyWithExecCommand(text) {
    try {
      const textArea = document.createElement('textarea');
      textArea.value = text;
      textArea.style.position = 'fixed';
      textArea.style.top = '0';
      textArea.style.left = '0';
      textArea.style.opacity = '0';
      textArea.style.pointerEvents = 'none';
      
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      
      const successful = document.execCommand('copy');
      document.body.removeChild(textArea);
      
      if (!successful) {
        throw new Error('execCommand failed');
      }
      
      console.log('✅ execCommand success');
      return true;
    } catch (err) {
      console.error('❌ All copy methods failed:', err);
      this.showToast('❌ Copy Failed', 'Please copy manually', 'error', 2000);
      return false;
    }
  }

  /**
   * Launch game
   */
  async launchGame(urlOrPath) {
    if (!urlOrPath || urlOrPath.trim() === '') {
      return { success: false, error: 'No URL provided' };
    }

    try {
      console.log('🚀 Launching game:', urlOrPath);

      if (this.isElectron && window.electron?.shell?.openExternal) {
        await window.electron.shell.openExternal(urlOrPath);
      } else {
        if (urlOrPath.startsWith('http://') || urlOrPath.startsWith('https://')) {
          window.open(urlOrPath, '_blank', 'noopener,noreferrer');
        } else {
          window.location.href = urlOrPath;
        }
      }
      
      this.showToast('🎮 Game Launched!', `Opening: ${urlOrPath}`, 'success', 2000);
      return { success: true };
    } catch (error) {
      console.error('Launch failed:', error);
      this.showToast('❌ Launch Failed', error.message, 'error', 3000);
      return { success: false, error: error.message };
    }
  }

  /**
   * Play alert sound
   */
  playAlertSound() {
    try {
      const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBDWM0fPTgjMGHm7A7+OZSA0PVqzn77BdGAg+ltryxnMpBCl+zPLaizsIGGS57OihUBALTKXh8bllHAU2jdXyzn0vBSF1xe/glEILElyx6OytWBUIQpzd8sFuJAMuh9Dz1YU2Bhxqvu7mnEoODlOo5O+zYBoGPJPY8sp2KwUnfMny3I4+CRZiturqpVIRC0mi4PK8aB8DMIvU89GBMwYebL/v6JxLDg5Tpu/zYhwFNozV8sp3LAUnfcny3Y8/CRVhtuvpo1QQC0ul4fG6ZR0FNo3V8tGBMwYebL/v6JxLDg5Tpu/zYhwFNozV8sp3LAUnfcny3Y8/CRVhtuvpo1QQC0ul4fG6ZR0FNo3V8tGBMwYebL/v6JxLDg5Tpu/zYhwFNozV8sp3LAUnfcny3Y8/CRVhtuvpo1QQC0ul4fG6ZR0FNo3V8tGBMwYebL/v6JxLDg5Tpu/zYhwFNozV8sp3LAUnfcny3Y8/CRVhtuvpo1QQC0ul4fG6ZR0FNo3V8tGBMwYebL/v6JxLDg5Tpu/zYhwFNozV8sp3LAUnfcny3Y8/CRVhtuvpo1QQC0ul4fG6ZR0FNo3V8tGBMwYebL/v6JxLDg5Tpu/zYhwFNozV8sp3LAUnfcny3Y8/CRVhtuvpo1QQC0ul4fG6ZR0FNo3V8tGBMwYebL/v6JxLDg5Tpu/zYhwFNozV8sp3LAUnfcny3Y8/CRVhtuvpo1QQC0ul4fG6ZR0FNo3V8tGBMwYebL/v6JxLDg5Tpu/zYhwFNozV8sp3LAUnfcny3Y8/CRVhtuvpo1QQC0ul4fG6ZR0FNo3V8tGBMwYebL/v6JxLDg5Tpu/zYhwFNozV8sp3LAUnfcny3Y8/CRVhtuvpo1QQC0ul4fG6ZR0FNo3V8tGBMwYebL/v6JxLDg5Tpu/zYhwFNozV8sp3LAUnfcny3Y8/CRVhtuvpo1QQC0ul4fG6ZR0FNo3V8tGBMwYebL/v6JxLDg5Tpu/zYhwFNozV8sp3LAUnfcny3Y8/CRVhtuvpo1QQC0ul4fG6ZR0FNo3V8tGBMwYebL/v6JxLDg5Tpu/zYhwFNozV8sp3LAUnfcny3Y8/CRVhtuvpo1QQC0ul4fG6ZR0FNo3V8tGBMwYebL/v6JxLDg5Tpu/zYhwFNozV8sp3LAUnfcny3Y8/CRVhtuvpo1QQC0ul4fG6ZR0FNo3V8tGBMwYebL/v6JxLDg5Tpu/zYhwFNozV8sp3LAUnfcny3Y8/CRVhtuvpo1QQC0ul4fG6ZR0FNo3V8tGBMwYebL/v6JxLDg==');
      audio.volume = 0.3;
      audio.play().catch(() => {});
    } catch (e) {}
  }

  /**
   * Show notification
   */
  showNotification(title, message, options = {}) {
    const { duration = 3000, type = 'info' } = options;

    if (this.isElectron && window.electron.showNotification) {
      window.electron.showNotification({ title, body: message });
    } else if ('Notification' in window && Notification.permission === 'granted') {
      new Notification(title, { body: message });
    } else {
      console.log(`[${title}] ${message}`);
      this.showToast(title, message, type, duration);
    }
  }

  /**
   * Show toast
   */
  showToast(title, message, type = 'info', duration = 3000) {
    const existing = document.getElementById('gam-toast');
    if (existing) existing.remove();

    const colors = {
      info: 'bg-blue-600',
      success: 'bg-green-600',
      warning: 'bg-yellow-600',
      error: 'bg-red-600',
    };

    const toast = document.createElement('div');
    toast.id = 'gam-toast';
    toast.className = `fixed bottom-4 right-4 ${colors[type]} text-white px-6 py-4 rounded-lg shadow-2xl z-[9999] max-w-sm`;
    toast.innerHTML = `
      <div class="flex items-start gap-3">
        <span class="text-2xl">${this.getIcon(type)}</span>
        <div class="flex-1">
          <h4 class="font-bold text-sm mb-1">${title}</h4>
          <p class="text-xs opacity-90">${message}</p>
        </div>
        <button onclick="this.parentElement.parentElement.remove()" class="text-white/80 hover:text-white">✕</button>
      </div>
    `;

    document.body.appendChild(toast);

    if (duration > 0) {
      setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(20px)';
        toast.style.transition = 'all 0.3s';
        setTimeout(() => toast.remove(), 300);
      }, duration);
    }
  }

  getIcon(type) {
    const icons = {
      info: '🎮',
      success: '✅',
      warning: '⚠️',
      error: '❌',
    };
    return icons[type] || '🎮';
  }

  async requestNotificationPermission() {
    if ('Notification' in window && Notification.permission === 'default') {
      const permission = await Notification.requestPermission();
      return permission === 'granted';
    }
    return Notification.permission === 'granted';
  }

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  getClickCount() {
    return parseInt(sessionStorage.getItem('gam-click-count') || '0');
  }

  setClickCount(count) {
    sessionStorage.setItem('gam-click-count', count.toString());
  }

  getRecommendedMethod() {
    return this.isElectron ? 'autoType' : 'twoClickLogin';
  }
}

export default QuickLoginService;