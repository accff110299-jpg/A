import { v4 as uuidv4 } from 'uuid';
import { CryptoService } from '../crypto/CryptoService';

/**
 * Service quản lý tài khoản game
 * Xử lý CRUD operations, filtering, sorting
 */
export class AccountService {
  constructor(masterPassword = '') {
    this.masterPassword = masterPassword;
  }

  /**
   * Set master password cho encryption/decryption
   * @param {string} password
   */
  setMasterPassword(password) {
    this.masterPassword = password;
  }

  /**
   * Tạo tài khoản mới
   * @param {Object} accountData
   * @returns {Object}
   */
  createAccount(accountData) {
    if (!this.masterPassword) {
      throw new Error('Master password not set');
    }

    const now = Date.now();
    const account = {
      id: uuidv4(),
      name: accountData.name || 'Unnamed Account',
      username: accountData.username || '',
      password: accountData.password || '',
      email: accountData.email,
      platform: accountData.platform || 'CUSTOM',
      tags: accountData.tags || [],
      avatar: accountData.avatar,
      notes: accountData.notes,
      createdAt: now,
      updatedAt: now,
      lastUsed: undefined,
      useCount: 0,
      isFavorite: accountData.isFavorite || false,
      macros: accountData.macros || [],
      sessionData: accountData.sessionData,
    };

    // Mã hóa password trước khi lưu
    const encryptedPassword = CryptoService.encrypt(
      account.password,
      this.masterPassword
    );
    account.password = JSON.stringify(encryptedPassword);

    return account;
  }

  /**
   * Cập nhật tài khoản
   * @param {string} accountId
   * @param {Object} updates
   * @param {Array} accounts
   * @returns {Array}
   */
  updateAccount(accountId, updates, accounts) {
    if (!this.masterPassword) {
      throw new Error('Master password not set');
    }

    return accounts.map((account) => {
      if (account.id === accountId) {
        const updated = {
          ...account,
          ...updates,
          updatedAt: Date.now(),
        };

        // Nếu có cập nhật password, mã hóa lại
        if (updates.password && updates.password !== account.password) {
          const encryptedPassword = CryptoService.encrypt(
            updates.password,
            this.masterPassword
          );
          updated.password = JSON.stringify(encryptedPassword);
        }

        return updated;
      }
      return account;
    });
  }

  /**
   * Xóa tài khoản
   * @param {string} accountId
   * @param {Array} accounts
   * @returns {Array}
   */
  deleteAccount(accountId, accounts) {
    return accounts.filter((account) => account.id !== accountId);
  }

  /**
   * Lấy password đã giải mã
   * @param {Object} account
   * @returns {string}
   */
  getDecryptedPassword(account) {
    if (!this.masterPassword) {
      throw new Error('Master password not set');
    }

    try {
      const encryptedData = JSON.parse(account.password);
      return CryptoService.decrypt(encryptedData, this.masterPassword);
    } catch (error) {
      throw new Error('Failed to decrypt password: ' + error.message);
    }
  }

  /**
   * Đánh dấu tài khoản được sử dụng
   * @param {string} accountId
   * @param {Array} accounts
   * @returns {Array}
   */
  markAsUsed(accountId, accounts) {
    return accounts.map((account) => {
      if (account.id === accountId) {
        return {
          ...account,
          lastUsed: Date.now(),
          useCount: account.useCount + 1,
        };
      }
      return account;
    });
  }

  /**
   * Toggle favorite
   * @param {string} accountId
   * @param {Array} accounts
   * @returns {Array}
   */
  toggleFavorite(accountId, accounts) {
    return accounts.map((account) => {
      if (account.id === accountId) {
        return {
          ...account,
          isFavorite: !account.isFavorite,
        };
      }
      return account;
    });
  }

  /**
   * Filter và sort accounts
   * @param {Array} accounts
   * @param {Object} filter
   * @returns {Array}
   */
  filterAndSortAccounts(accounts, filter) {
    let filtered = [...accounts];

    // Search by name, username, email
    if (filter.searchTerm) {
      const term = filter.searchTerm.toLowerCase();
      filtered = filtered.filter(
        (acc) =>
          acc.name.toLowerCase().includes(term) ||
          acc.username.toLowerCase().includes(term) ||
          acc.email?.toLowerCase().includes(term) ||
          acc.tags.some((tag) => tag.toLowerCase().includes(term))
      );
    }

    // Filter by platforms
    if (filter.platforms && filter.platforms.length > 0) {
      filtered = filtered.filter((acc) =>
        filter.platforms.includes(acc.platform)
      );
    }

    // Filter by tags
    if (filter.tags && filter.tags.length > 0) {
      filtered = filtered.filter((acc) =>
        filter.tags.some((tag) => acc.tags.includes(tag))
      );
    }

    // Filter by favorites
    if (filter.favorites) {
      filtered = filtered.filter((acc) => acc.isFavorite);
    }

    // Sort
    if (filter.sortBy) {
      filtered.sort((a, b) => {
        let compareA;
        let compareB;

        switch (filter.sortBy) {
          case 'name':
            compareA = a.name.toLowerCase();
            compareB = b.name.toLowerCase();
            break;
          case 'platform':
            compareA = a.platform;
            compareB = b.platform;
            break;
          case 'createdAt':
            compareA = a.createdAt;
            compareB = b.createdAt;
            break;
          case 'lastUsed':
            compareA = a.lastUsed || 0;
            compareB = b.lastUsed || 0;
            break;
          case 'useCount':
            compareA = a.useCount;
            compareB = b.useCount;
            break;
          default:
            return 0;
        }

        if (compareA < compareB) return filter.sortOrder === 'asc' ? -1 : 1;
        if (compareA > compareB) return filter.sortOrder === 'asc' ? 1 : -1;
        return 0;
      });
    }

    return filtered;
  }

  /**
   * Lấy thống kê tài khoản
   * @param {Array} accounts
   * @returns {Object}
   */
  getStats(accounts) {
    const platformCounts = {};

    accounts.forEach((acc) => {
      platformCounts[acc.platform] = (platformCounts[acc.platform] || 0) + 1;
    });

    const sortedByLastUsed = [...accounts]
      .filter((acc) => acc.lastUsed)
      .sort((a, b) => (b.lastUsed || 0) - (a.lastUsed || 0))
      .slice(0, 5);

    const sortedByUseCount = [...accounts]
      .sort((a, b) => b.useCount - a.useCount)
      .slice(0, 5);

    return {
      totalAccounts: accounts.length,
      platformCounts,
      recentlyUsed: sortedByLastUsed,
      mostUsed: sortedByUseCount,
    };
  }

  /**
   * Export accounts ra file
   * @param {Array} accounts
   * @param {Array} groups
   * @returns {Object}
   */
  exportAccounts(accounts, groups) {
    return {
      version: '1.0.0',
      accounts,
      groups,
      exportedAt: Date.now(),
    };
  }

  /**
   * Import accounts từ file
   * @param {Object} data
   * @returns {Object}
   */
  importAccounts(data) {
    // Validate version compatibility
    if (!data.version || data.version !== '1.0.0') {
      throw new Error('Incompatible export version');
    }

    return {
      accounts: data.accounts || [],
      groups: data.groups || [],
    };
  }

  /**
   * Tạo group mới
   * @param {Object} groupData
   * @returns {Object}
   */
  createGroup(groupData) {
    return {
      id: uuidv4(),
      name: groupData.name || 'New Group',
      color: groupData.color || '#3b82f6',
      accountIds: groupData.accountIds || [],
      createdAt: Date.now(),
    };
  }

  /**
   * Lấy tất cả tags unique
   * @param {Array} accounts
   * @returns {Array}
   */
  getAllTags(accounts) {
    const tagSet = new Set();
    accounts.forEach((acc) => {
      acc.tags.forEach((tag) => tagSet.add(tag));
    });
    return Array.from(tagSet).sort();
  }
}