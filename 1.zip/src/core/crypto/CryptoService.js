import CryptoJS from 'crypto-js';

/**
 * Service xử lý mã hóa/giải mã dữ liệu với AES-256
 * Sử dụng PBKDF2 để derive key từ master password
 */
export class CryptoService {
  static ITERATIONS = 10000;
  static KEY_SIZE = 256;
  static SALT_SIZE = 128;

  /**
   * Tạo salt ngẫu nhiên
   * @returns {string}
   */
  static generateSalt() {
    return CryptoJS.lib.WordArray.random(this.SALT_SIZE / 8).toString();
  }

  /**
   * Derive key từ master password sử dụng PBKDF2
   * @param {string} password
   * @param {string} salt
   * @returns {string}
   */
  static deriveKey(password, salt) {
    return CryptoJS.PBKDF2(password, salt, {
      keySize: this.KEY_SIZE / 32,
      iterations: this.ITERATIONS,
    }).toString();
  }

  /**
   * Mã hóa dữ liệu với AES-256-CBC
   * @param {string} data - Dữ liệu cần mã hóa
   * @param {string} masterPassword - Master password
   * @returns {Object} Object chứa encrypted data, salt và IV
   */
  static encrypt(data, masterPassword) {
    try {
      // Tạo salt và derive key
      const salt = this.generateSalt();
      const key = this.deriveKey(masterPassword, salt);

      // Tạo IV ngẫu nhiên
      const iv = CryptoJS.lib.WordArray.random(128 / 8);

      // Mã hóa
      const encrypted = CryptoJS.AES.encrypt(data, CryptoJS.enc.Hex.parse(key), {
        iv: iv,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      });

      return {
        ciphertext: encrypted.ciphertext.toString(CryptoJS.enc.Base64),
        salt: salt,
        iv: iv.toString(CryptoJS.enc.Base64),
      };
    } catch (error) {
      throw new Error(`Encryption failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Giải mã dữ liệu
   * @param {Object} encryptedData - Dữ liệu đã mã hóa
   * @param {string} masterPassword - Master password
   * @returns {string} Dữ liệu đã giải mã
   */
  static decrypt(encryptedData, masterPassword) {
    try {
      // Derive key từ password và salt
      const key = this.deriveKey(masterPassword, encryptedData.salt);

      // Parse IV
      const iv = CryptoJS.enc.Base64.parse(encryptedData.iv);

      // Giải mã
      const decrypted = CryptoJS.AES.decrypt(
        encryptedData.ciphertext,
        CryptoJS.enc.Hex.parse(key),
        {
          iv: iv,
          mode: CryptoJS.mode.CBC,
          padding: CryptoJS.pad.Pkcs7,
        }
      );

      const decryptedText = decrypted.toString(CryptoJS.enc.Utf8);
      
      if (!decryptedText) {
        throw new Error('Decryption failed - invalid password or corrupted data');
      }

      return decryptedText;
    } catch (error) {
      throw new Error(`Decryption failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Hash password với SHA-256 để lưu trữ (cho việc verify master password)
   * @param {string} password
   * @returns {string}
   */
  static hashPassword(password) {
    return CryptoJS.SHA256(password).toString();
  }

  /**
   * Verify master password
   * @param {string} password
   * @param {string} hash
   * @returns {boolean}
   */
  static verifyPassword(password, hash) {
    return this.hashPassword(password) === hash;
  }

  /**
   * Tạo mật khẩu ngẫu nhiên mạnh
   * @param {number} length - Độ dài mật khẩu
   * @param {Object} options - Tùy chọn ký tự
   * @returns {string}
   */
  static generatePassword(length = 16, options = {}) {
    const {
      uppercase = true,
      lowercase = true,
      numbers = true,
      symbols = true,
    } = options;

    let charset = '';
    if (uppercase) charset += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    if (lowercase) charset += 'abcdefghijklmnopqrstuvwxyz';
    if (numbers) charset += '0123456789';
    if (symbols) charset += '!@#$%^&*()_+-=[]{}|;:,.<>?';

    if (charset.length === 0) {
      throw new Error('At least one character type must be selected');
    }

    let password = '';
    const randomValues = new Uint32Array(length);
    crypto.getRandomValues(randomValues);

    for (let i = 0; i < length; i++) {
      password += charset[randomValues[i] % charset.length];
    }

    return password;
  }

  /**
   * Xóa dữ liệu nhạy cảm khỏi memory
   * @param {any} data
   */
  static secureErase(data) {
    if (typeof data === 'string') {
      const length = data.length;
      data = CryptoJS.lib.WordArray.random(length).toString();
    } else if (typeof data === 'object') {
      for (const key in data) {
        if (data.hasOwnProperty(key)) {
          data[key] = null;
        }
      }
    }
  }
}