import React from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useAppStore } from './store/useAppStore';

// Screens
import Dashboard from './ui/screens/dashboard';
import Login from './ui/screens/login';
import Settings from './ui/screens/settings';
import ActivityLog from './ui/screens/activitylog';
import AccountsList from './ui/screens/AccountsList';
import GroupsManager from './ui/screens/GroupsManager';
import GamesManager from './ui/screens/GamesManager';

// Components
import Sidebar from './ui/components/sidebar';

function App() {
  const { isAuthenticated, isLocked, settings, loadGames } = useAppStore();

  // Theme management
  React.useEffect(() => {
    const updateTheme = () => {
      if (settings.theme === 'dark') {
        document.documentElement.classList.add('dark');
      } else if (settings.theme === 'light') {
        document.documentElement.classList.remove('dark');
      } else {
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        if (prefersDark) {
          document.documentElement.classList.add('dark');
        } else {
          document.documentElement.classList.remove('dark');
        }
      }
    };

    updateTheme();

    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handler = () => updateTheme();
    mediaQuery.addEventListener('change', handler);

    return () => mediaQuery.removeEventListener('change', handler);
  }, [settings.theme]);

  // Load games khi app khởi động
  React.useEffect(() => {
    if (isAuthenticated && !isLocked) {
      loadGames();
    }
  }, [isAuthenticated, isLocked, loadGames]);

  // Auto-lock timer
  React.useEffect(() => {
    if (!settings.autoLock || !isAuthenticated || isLocked) return;

    let timeout;
    
    const resetTimer = () => {
      clearTimeout(timeout);
      timeout = setTimeout(() => {
        useAppStore.getState().lock();
      }, settings.autoLockTimeout * 60 * 1000);
    };

    const events = ['mousedown', 'keydown', 'scroll', 'touchstart'];
    events.forEach(event => {
      document.addEventListener(event, resetTimer);
    });

    resetTimer();

    return () => {
      clearTimeout(timeout);
      events.forEach(event => {
        document.removeEventListener(event, resetTimer);
      });
    };
  }, [settings.autoLock, settings.autoLockTimeout, isAuthenticated, isLocked]);

  // Show login if not authenticated or locked
  if (!isAuthenticated || isLocked) {
    return (
      <div className="h-screen w-screen bg-gradient-to-br from-primary-50 to-primary-100 dark:from-dark-900 dark:to-dark-800">
        <Login />
      </div>
    );
  }

  return (
    <Router>
      <div className="flex h-screen bg-dark-50 dark:bg-dark-900">
        <Sidebar />
        
        <main className="flex-1 overflow-auto">
          <div className="container mx-auto p-6 max-w-7xl">
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/accounts" element={<AccountsList />} />
              <Route path="/groups" element={<GroupsManager />} />
              <Route path="/games" element={<GamesManager />} />
              <Route path="/settings" element={<Settings />} />
              <Route path="/activity" element={<ActivityLog />} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </div>
        </main>
      </div>
    </Router>
  );
}

export default App;