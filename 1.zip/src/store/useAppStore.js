import { create } from 'zustand';
import { AccountService } from '../core/account/AccountService';
import { StorageService } from '../core/storage/StorageService';

export const useAppStore = create((set, get) => {
  const storageService = new StorageService();
  const accountService = new AccountService();

  // Load games ngay khi khởi tạo
  const initialGames = storageService.getGames();

  return {
    // Initial state
    isLocked: false,
    isAuthenticated: false,
    masterPassword: '',
    accountService,
    storageService,
    accounts: [],
    groups: [],
    games: initialGames, // Load games từ storage
    settings: storageService.getSettings(),
    activityLog: [],
    selectedAccountId: null,
    viewMode: 'grid',
    filter: {},

    // Auth actions
    setMasterPassword: (password) => {
      accountService.setMasterPassword(password);
      set({ masterPassword: password, isAuthenticated: true });
      
      // Load all data khi set password
      get().loadAccounts();
      get().loadGroups();
      get().loadGames();
    },

    lock: () => {
      set({
        isLocked: true,
        isAuthenticated: false,
        masterPassword: '',
        selectedAccountId: null,
      });
      
      // Clear sensitive data from memory
      accountService.setMasterPassword('');
    },

    unlock: async (password) => {
      const { storageService, accountService } = get();
      const storedHash = storageService.getMasterPasswordHash();
      
      // Import CryptoService dynamically để avoid circular dependencies
      const { CryptoService } = await import('../core/crypto/CryptoService');
      
      if (CryptoService.verifyPassword(password, storedHash)) {
        accountService.setMasterPassword(password);
        set({
          isLocked: false,
          isAuthenticated: true,
          masterPassword: password,
        });
        
        // Reload all data
        get().loadAccounts();
        get().loadGroups();
        get().loadGames(); // Quan trọng: load games khi unlock
        get().loadActivityLog();
        
        return true;
      }
      
      return false;
    },

    // Account actions
    loadAccounts: () => {
      const { storageService } = get();
      const accounts = storageService.getAccounts();
      set({ accounts });
    },

    addAccount: (accountData) => {
      const { accountService, storageService } = get();
      
      try {
        const newAccount = accountService.createAccount(accountData);
        storageService.addAccount(newAccount);
        get().loadAccounts();
      } catch (error) {
        console.error('Failed to add account:', error);
        throw error;
      }
    },

    updateAccount: (id, updates) => {
      const { accountService, storageService, accounts } = get();
      
      try {
        const updatedAccounts = accountService.updateAccount(id, updates, accounts);
        storageService.saveAccounts(updatedAccounts);
        set({ accounts: updatedAccounts });
      } catch (error) {
        console.error('Failed to update account:', error);
        throw error;
      }
    },

    deleteAccount: (id) => {
      const { storageService } = get();
      storageService.deleteAccount(id);
      get().loadAccounts();
      
      if (get().selectedAccountId === id) {
        set({ selectedAccountId: null });
      }
    },

    selectAccount: (id) => {
      set({ selectedAccountId: id });
    },

    toggleFavorite: (id) => {
      const { accountService, storageService, accounts } = get();
      const updatedAccounts = accountService.toggleFavorite(id, accounts);
      storageService.saveAccounts(updatedAccounts);
      set({ accounts: updatedAccounts });
    },

    markAccountAsUsed: (id) => {
      const { accountService, storageService, accounts } = get();
      const updatedAccounts = accountService.markAsUsed(id, accounts);
      storageService.saveAccounts(updatedAccounts);
      set({ accounts: updatedAccounts });
    },

    // Group actions
    loadGroups: () => {
      const { storageService } = get();
      const groups = storageService.getGroups();
      set({ groups });
    },

    addGroup: (groupData) => {
      const { accountService, storageService } = get();
      const newGroup = accountService.createGroup(groupData);
      storageService.addGroup(newGroup);
      get().loadGroups();
    },

    updateGroup: (id, updates) => {
      const { storageService } = get();
      storageService.updateGroup(id, updates);
      get().loadGroups();
    },

    deleteGroup: (id) => {
      const { storageService } = get();
      storageService.deleteGroup(id);
      get().loadGroups();
    },

    // Games actions
    loadGames: () => {
      const { storageService } = get();
      const games = storageService.getGames();
      set({ games });
    },

    addGame: (gameData) => {
      const { storageService } = get();
      const newGame = {
        id: Date.now().toString(),
        name: gameData.name.trim(),
        url: gameData.url?.trim() || '',
        createdAt: Date.now(),
      };
      const currentGames = get().games || [];
      const updatedGames = [...currentGames, newGame];
      storageService.saveGames(updatedGames);
      set({ games: updatedGames });
      
      get().addLog({
        type: 'create',
        message: `Đã thêm game mới: ${newGame.name}`,
        severity: 'info',
      });
    },

    updateGame: (id, updates) => {
      const { storageService } = get();
      const updatedGames = get().games.map(g => 
        g.id === id ? { ...g, ...updates, updatedAt: Date.now() } : g
      );
      storageService.saveGames(updatedGames);
      set({ games: updatedGames });
      
      get().addLog({
        type: 'update',
        message: `Đã cập nhật game: ${updates.name || id}`,
        severity: 'info',
      });
    },

    deleteGame: (id) => {
      const { storageService } = get();
      const gameName = get().games.find(g => g.id === id)?.name || id;
      const updatedGames = get().games.filter(g => g.id !== id);
      storageService.saveGames(updatedGames);
      set({ games: updatedGames });
      
      get().addLog({
        type: 'delete',
        message: `Đã xóa game: ${gameName}`,
        severity: 'warning',
      });
    },

    // Settings actions
    loadSettings: () => {
      const { storageService } = get();
      const settings = storageService.getSettings();
      set({ settings });
    },

    updateSettings: (updates) => {
      const { storageService } = get();
      storageService.updateSettings(updates);
      get().loadSettings();
    },

    // Filter actions
    setFilter: (filterUpdates) => {
      set((state) => ({
        filter: { ...state.filter, ...filterUpdates },
      }));
    },

    clearFilter: () => {
      set({ filter: {} });
    },

    // View actions
    setViewMode: (mode) => {
      set({ viewMode: mode });
    },

    // Activity log actions
    loadActivityLog: () => {
      const { storageService } = get();
      const activityLog = storageService.getActivityLog(100);
      set({ activityLog });
    },

    addLog: (entry) => {
      const { storageService } = get();
      storageService.addActivityLog(entry);
      get().loadActivityLog();
    },

    // Import/Export actions
    exportData: () => {
      const { accounts, groups, games } = get();
      const data = {
        version: '1.0.0',
        accounts,
        groups,
        games: games || [],
        exportedAt: Date.now(),
      };
      return JSON.stringify(data, null, 2);
    },

    importData: (jsonString) => {
      const { storageService } = get();
      
      try {
        const data = JSON.parse(jsonString);
        
        if (data.accounts) storageService.saveAccounts(data.accounts);
        if (data.groups) storageService.saveGroups(data.groups);
        if (data.games) storageService.saveGames(data.games);
        
        get().loadAccounts();
        get().loadGroups();
        get().loadGames();
        
        storageService.addActivityLog({
          type: 'import',
          message: 'Đã import dữ liệu đầy đủ (bao gồm games)',
          severity: 'info',
        });
      } catch (error) {
        console.error('Import failed:', error);
        throw new Error('File không hợp lệ');
      }
    },
  };
});