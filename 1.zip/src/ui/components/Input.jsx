import React from 'react';

/**
 * Input Component
 * @param {Object} props
 * @param {string} props.value
 * @param {Function} props.onChange
 * @param {string} props.placeholder
 * @param {React.ReactNode} props.icon
 * @param {string} props.type
 * @param {string} props.className
 */
export const Input = ({
  value,
  onChange,
  placeholder = '',
  icon = null,
  type = 'text',
  className = '',
  ...props
}) => {
  return (
    <div className={`relative ${className}`}>
      {icon && (
        <div className="absolute left-3 top-1/2 -translate-y-1/2 text-dark-400">
          {icon}
        </div>
      )}
      <input
        type={type}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        className={`w-full ${
          icon ? 'pl-10' : 'pl-4'
        } pr-4 py-2 bg-white dark:bg-dark-800 border border-dark-200 dark:border-dark-700 rounded-lg text-dark-900 dark:text-white placeholder-dark-400 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all`}
        {...props}
      />
    </div>
  );
};

export default Input;