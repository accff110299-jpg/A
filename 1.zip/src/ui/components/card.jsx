import React from 'react';
import { motion } from 'framer-motion';

/**
 * Card Component
 * @param {Object} props
 * @param {React.ReactNode} props.children
 * @param {string} props.className
 * @param {boolean} props.hoverable
 * @param {boolean} props.glass
 * @param {Function} props.onClick
 */
export const Card = ({
  children,
  className = '',
  hoverable = false,
  glass = false,
  onClick
}) => {
  const baseStyles = 'rounded-xl transition-all duration-200';
  
  const normalStyles = glass
    ? 'bg-white/10 dark:bg-dark-800/10 backdrop-blur-lg border border-white/20 dark:border-dark-700/20'
    : 'bg-white dark:bg-dark-800 border border-dark-200 dark:border-dark-700 shadow-sm';
  
  const hoverStyles = hoverable
    ? 'cursor-pointer hover:shadow-lg hover:border-primary-300 dark:hover:border-primary-700'
    : '';

  const Component = hoverable ? motion.div : 'div';
  const motionProps = hoverable
    ? {
        whileHover: { scale: 1.02, y: -2 },
        whileTap: { scale: 0.98 },
      }
    : {};

  return (
    <Component
      className={`${baseStyles} ${normalStyles} ${hoverStyles} ${className}`}
      onClick={onClick}
      {...motionProps}
    >
      {children}
    </Component>
  );
};
export default Card;