import React from 'react';
import { Card } from './Card';
import { Button } from './Button';
import { 
  Star, 
  Trash2, 
  Edit3, 
  Copy, 
  ExternalLink,
  Clock
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

/**
 * AccountCard Component
 * @param {Object} props
 * @param {Object} props.account
 * @param {string} props.viewMode - 'grid' or 'list'
 * @param {Function} props.onLaunch
 * @param {Function} props.onEdit
 * @param {Function} props.onDelete
 * @param {Function} props.onToggleFavorite
 * @param {Function} props.onCopyPassword
 */
export const AccountCard = ({
  account,
  viewMode = 'grid',
  onLaunch,
  onEdit,
  onDelete,
  onToggleFavorite,
  onCopyPassword,
}) => {
  const isGridView = viewMode === 'grid';

  const handleLaunch = (e) => {
    e.stopPropagation();
    onLaunch?.(account);
  };

  const handleEdit = (e) => {
    e.stopPropagation();
    onEdit?.(account);
  };

  const handleDelete = (e) => {
    e.stopPropagation();
    onDelete?.(account);
  };

  const handleToggleFavorite = (e) => {
    e.stopPropagation();
    onToggleFavorite?.(account);
  };

  const handleCopyPassword = (e) => {
    e.stopPropagation();
    onCopyPassword?.(account);
  };

  if (isGridView) {
    return (
      <Card className="p-5 hover:shadow-lg transition-shadow" hoverable>
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1 min-w-0">
            <h3 className="font-bold text-lg text-dark-900 dark:text-white truncate">
              {account.name || account.username || 'Unnamed Account'}
            </h3>
            <p className="text-sm text-dark-600 dark:text-dark-400 truncate">
              {account.game || 'No game'}
            </p>
          </div>
          
          <button
            onClick={handleToggleFavorite}
            className="ml-2 text-dark-400 hover:text-yellow-500 transition-colors"
          >
            <Star
              size={20}
              className={account.isFavorite ? 'fill-yellow-500 text-yellow-500' : ''}
            />
          </button>
        </div>

        {account.lastUsed && (
          <div className="flex items-center gap-1 text-xs text-dark-500 dark:text-dark-400 mb-3">
            <Clock size={12} />
            <span>Used {formatDistanceToNow(account.lastUsed, { addSuffix: true })}</span>
          </div>
        )}

        <div className="flex gap-2">
          <Button
            size="sm"
            onClick={handleLaunch}
            fullWidth
            icon={<ExternalLink size={16} />}
          >
            Launch
          </Button>
          <Button
            size="sm"
            variant="secondary"
            onClick={handleCopyPassword}
            icon={<Copy size={16} />}
          />
          <Button
            size="sm"
            variant="secondary"
            onClick={handleEdit}
            icon={<Edit3 size={16} />}
          />
          <Button
            size="sm"
            variant="danger"
            onClick={handleDelete}
            icon={<Trash2 size={16} />}
          />
        </div>
      </Card>
    );
  }

  // List view
  return (
    <Card className="p-4 hover:shadow-md transition-shadow" hoverable>
      <div className="flex items-center gap-4">
        <button
          onClick={handleToggleFavorite}
          className="text-dark-400 hover:text-yellow-500 transition-colors"
        >
          <Star
            size={20}
            className={account.isFavorite ? 'fill-yellow-500 text-yellow-500' : ''}
          />
        </button>

        <div className="flex-1 min-w-0">
          <div className="flex items-baseline gap-3 mb-1">
            <h3 className="font-bold text-lg text-dark-900 dark:text-white">
              {account.name || account.username || 'Unnamed Account'}
            </h3>
            <span className="text-sm text-dark-600 dark:text-dark-400">
              {account.game || 'No game'}
            </span>
          </div>
          
          {account.lastUsed && (
            <div className="flex items-center gap-1 text-xs text-dark-500 dark:text-dark-400">
              <Clock size={12} />
              <span>Used {formatDistanceToNow(account.lastUsed, { addSuffix: true })}</span>
            </div>
          )}
        </div>

        <div className="flex gap-2">
          <Button
            size="sm"
            onClick={handleLaunch}
            icon={<ExternalLink size={16} />}
          >
            Launch
          </Button>
          <Button
            size="sm"
            variant="secondary"
            onClick={handleCopyPassword}
            icon={<Copy size={16} />}
          />
          <Button
            size="sm"
            variant="secondary"
            onClick={handleEdit}
            icon={<Edit3 size={16} />}
          />
          <Button
            size="sm"
            variant="danger"
            onClick={handleDelete}
            icon={<Trash2 size={16} />}
          />
        </div>
      </div>
    </Card>
  );
};

export default AccountCard;