import React from 'react';
import { NavLink } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  LayoutDashboard,
  Settings,
  Activity,
  Lock,
  Sun,
  Moon,
  Shield,
  Users,       // thêm
  Folder,      // thêm
  Gamepad2,    // thêm
} from 'lucide-react';
import { useAppStore } from '../../store/useAppStore';

export const Sidebar = () => {
  const { settings, updateSettings, lock } = useAppStore();

  const toggleTheme = () => {
    const newTheme = settings.theme === 'dark' ? 'light' : 'dark';
    updateSettings({ theme: newTheme });
  };

   const navItems = [
    { path: '/', icon: LayoutDashboard, label: 'Dashboard' },
    { path: '/accounts', icon: Users, label: 'Tài khoản' },
    { path: '/groups', icon: Folder, label: 'Nhóm' },
    { path: '/games', icon: Gamepad2, label: 'Games' },
    { path: '/activity', icon: Activity, label: 'Activity Log' },
    { path: '/settings', icon: Settings, label: 'Settings' },
  ];

  return (
    <aside className="w-64 bg-white dark:bg-dark-800 border-r border-dark-200 dark:border-dark-700 flex flex-col">
      {/* Logo */}
      <div className="p-6 border-b border-dark-200 dark:border-dark-700">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-primary-500 to-primary-700 rounded-lg flex items-center justify-center">
            <Shield className="text-white" size={24} />
          </div>
          <div>
            <h1 className="font-bold text-dark-900 dark:text-white">GAM</h1>
            <p className="text-xs text-dark-500 dark:text-dark-400">
              Account Manager
            </p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              `flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                isActive
                  ? 'bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300'
                  : 'text-dark-700 dark:text-dark-300 hover:bg-dark-100 dark:hover:bg-dark-700'
              }`
            }
          >
            {({ isActive }) => (
              <>
                <item.icon size={20} />
                <span className="font-medium">{item.label}</span>
                {isActive && (
                  <motion.div
                    layoutId="activeNav"
                    className="ml-auto w-1.5 h-1.5 bg-primary-600 rounded-full"
                  />
                )}
              </>
            )}
          </NavLink>
        ))}
      </nav>

      {/* Bottom Actions */}
      <div className="p-4 border-t border-dark-200 dark:border-dark-700 space-y-2">
        {/* Theme Toggle */}
        <button
          onClick={toggleTheme}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-dark-700 dark:text-dark-300 hover:bg-dark-100 dark:hover:bg-dark-700 transition-colors"
        >
          {settings.theme === 'dark' ? (
            <>
              <Sun size={20} />
              <span className="font-medium">Light Mode</span>
            </>
          ) : (
            <>
              <Moon size={20} />
              <span className="font-medium">Dark Mode</span>
            </>
          )}
        </button>

        {/* Lock Button */}
        <button
          onClick={lock}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-dark-700 dark:text-dark-300 hover:bg-red-100 dark:hover:bg-red-900/20 hover:text-red-600 dark:hover:text-red-400 transition-colors"
        >
          <Lock size={20} />
          <span className="font-medium">Lock App</span>
        </button>
      </div>
    </aside>
  );
};
export default Sidebar;