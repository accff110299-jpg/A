import React from 'react';
import { format } from 'date-fns';
import { Card } from '../components/Card';
import { Button } from '../components/Button';
import { useAppStore } from '../../store/useAppStore';
import {
  Activity,
  LogIn,
  Plus,
  Edit,
  Trash2,
  Download,
  Upload,
  AlertTriangle,
  Info,
  XCircle,
  Trash,
} from 'lucide-react';

 const ActivityLog = () => {
  const { activityLog, storageService } = useAppStore();

  const getIcon = (type) => {
    switch (type) {
      case 'login':
        return LogIn;
      case 'create':
        return Plus;
      case 'update':
        return Edit;
      case 'delete':
        return Trash2;
      case 'export':
        return Download;
      case 'import':
        return Upload;
      case 'security':
        return AlertTriangle;
      default:
        return Activity;
    }
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'error':
        return 'text-red-600 dark:text-red-400 bg-red-100 dark:bg-red-900/30';
      case 'warning':
        return 'text-yellow-600 dark:text-yellow-400 bg-yellow-100 dark:bg-yellow-900/30';
      default:
        return 'text-blue-600 dark:text-blue-400 bg-blue-100 dark:bg-blue-900/30';
    }
  };

  const getSeverityIcon = (severity) => {
    switch (severity) {
      case 'error':
        return XCircle;
      case 'warning':
        return AlertTriangle;
      default:
        return Info;
    }
  };

  const handleClearLog = () => {
    if (confirm('Are you sure you want to clear the activity log?')) {
      storageService.clearActivityLog();
      window.location.reload();
    }
  };

  return (
    <div className="max-w-4xl">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-dark-900 dark:text-white mb-2">
            Activity Log
          </h1>
          <p className="text-dark-600 dark:text-dark-400">
            Track all activities in your app
          </p>
        </div>

        <Button
          variant="danger"
          icon={<Trash size={18} />}
          onClick={handleClearLog}
        >
          Clear Log
        </Button>
      </div>

      {activityLog.length === 0 ? (
        <Card className="p-12 text-center">
          <div className="flex flex-col items-center gap-4">
            <div className="p-4 bg-dark-100 dark:bg-dark-800 rounded-full">
              <Activity size={48} className="text-dark-400" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-dark-900 dark:text-white mb-1">
                No activity yet
              </h3>
              <p className="text-dark-600 dark:text-dark-400">
                Activity will appear here as you use the app
              </p>
            </div>
          </div>
        </Card>
      ) : (
        <div className="space-y-3">
          {activityLog.map((entry) => {
            const Icon = getIcon(entry.type);
            const SeverityIcon = getSeverityIcon(entry.severity);

            return (
              <Card key={entry.id} className="p-4 hover:shadow-md transition-shadow">
                <div className="flex items-start gap-4">
                  {/* Icon */}
                  <div
                    className={`p-3 rounded-lg ${getSeverityColor(entry.severity)}`}
                  >
                    <Icon size={20} />
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1">
                        <p className="font-medium text-dark-900 dark:text-white">
                          {entry.message}
                        </p>
                        {entry.accountName && (
                          <p className="text-sm text-dark-600 dark:text-dark-400 mt-0.5">
                            Account: {entry.accountName}
                          </p>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        <SeverityIcon
                          size={16}
                          className={
                            entry.severity === 'error'
                              ? 'text-red-500'
                              : entry.severity === 'warning'
                              ? 'text-yellow-500'
                              : 'text-blue-500'
                          }
                        />
                      </div>
                    </div>

                    <div className="flex items-center gap-3 mt-2 text-xs text-dark-500 dark:text-dark-400">
                      <span>{format(entry.timestamp, 'PPpp')}</span>
                      <span>•</span>
                      <span className="capitalize">{entry.type}</span>
                    </div>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default ActivityLog;