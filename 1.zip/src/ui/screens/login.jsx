import React from 'react';
import { useAppStore } from '../../store/useAppStore';
import { Shield, Lock, AlertCircle } from 'lucide-react';
import { motion } from 'framer-motion';

const Login = () => {
  const { 
    unlock, 
    setMasterPassword, 
    storageService, 
    loadAccounts, 
    loadGroups, 
    loadGames 
  } = useAppStore();
  
  const [password, setPassword] = React.useState('');
  const [error, setError] = React.useState('');
  const [isCreating, setIsCreating] = React.useState(false);
  const [confirmPassword, setConfirmPassword] = React.useState('');

  // Check if master password exists
  React.useEffect(() => {
    const hash = storageService.getMasterPasswordHash();
    setIsCreating(!hash);
  }, [storageService]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (isCreating) {
      // Create new master password
      if (password.length < 6) {
        setError('Mật khẩu phải có ít nhất 6 ký tự');
        return;
      }
      if (password !== confirmPassword) {
        setError('Mật khẩu xác nhận không khớp');
        return;
      }

      // Save master password hash
      const { CryptoService } = await import('../../core/crypto/CryptoService');
      const hash = CryptoService.hashPassword(password);
      storageService.setMasterPasswordHash(hash);
      
      setMasterPassword(password);
      
      // Load all data including games
      loadAccounts();
      loadGroups();
      loadGames();
    } else {
      // Unlock with existing password
      const success = await unlock(password);
      if (!success) {
        setError('Mật khẩu không đúng');
        return;
      }
      
      // Load games after unlock
      loadGames();
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        <div className="bg-white dark:bg-dark-800 rounded-2xl shadow-2xl p-8">
          {/* Logo */}
          <div className="flex justify-center mb-8">
            <div className="w-20 h-20 bg-gradient-to-br from-primary-500 to-primary-700 rounded-2xl flex items-center justify-center shadow-lg">
              <Shield className="text-white" size={40} />
            </div>
          </div>

          {/* Title */}
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-dark-900 dark:text-white mb-2">
              GAM
            </h1>
            <p className="text-dark-600 dark:text-dark-400">
              {isCreating ? 'Tạo mật khẩu chính' : 'Nhập mật khẩu để mở khóa'}
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-dark-700 dark:text-dark-300 mb-2">
                Mật khẩu chính
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-dark-400" size={20} />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border border-dark-300 dark:border-dark-600 rounded-lg bg-white dark:bg-dark-700 text-dark-900 dark:text-white focus:ring-2 focus:ring-primary-500 outline-none"
                  placeholder="Nhập mật khẩu"
                  autoFocus
                />
              </div>
            </div>

            {isCreating && (
              <div>
                <label className="block text-sm font-medium text-dark-700 dark:text-dark-300 mb-2">
                  Xác nhận mật khẩu
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-dark-400" size={20} />
                  <input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 border border-dark-300 dark:border-dark-600 rounded-lg bg-white dark:bg-dark-700 text-dark-900 dark:text-white focus:ring-2 focus:ring-primary-500 outline-none"
                    placeholder="Nhập lại mật khẩu"
                  />
                </div>
              </div>
            )}

            {error && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-center gap-2 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg"
              >
                <AlertCircle className="text-red-600 dark:text-red-400" size={20} />
                <p className="text-sm text-red-600 dark:text-red-400">{error}</p>
              </motion.div>
            )}

            <button
              type="submit"
              className="w-full py-3 bg-gradient-to-r from-primary-500 to-primary-700 hover:from-primary-600 hover:to-primary-800 text-white font-medium rounded-lg transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              {isCreating ? 'Tạo mật khẩu' : 'Mở khóa'}
            </button>
          </form>

          {isCreating && (
            <div className="mt-6 p-4 bg-primary-50 dark:bg-primary-900/20 rounded-lg">
              <p className="text-sm text-primary-700 dark:text-primary-300">
                ⚠️ <strong>Lưu ý:</strong> Hãy nhớ mật khẩu này! Nếu quên, bạn sẽ mất toàn bộ dữ liệu.
              </p>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};

export default Login;