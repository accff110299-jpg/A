import React from 'react';
import { Card } from '../components/Card';
import { Button } from '../components/Button';
import { useAppStore } from '../../store/useAppStore';
import { Download, Upload, Trash2, Shield, Bell, Key } from 'lucide-react';

 const Settings = () => {
  const { settings, updateSettings, storageService, exportData, importData } = useAppStore();

const handleExport = () => {
    try {
      // Dùng hàm mới có games
      const data = useAppStore.getState().exportDataWithGames();
      const blob = new Blob([data], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `gam-backup-full-${Date.now()}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Export failed:', error);
    }
  };

const handleImport = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = async (e) => {
      const file = e.target.files?.[0];
      if (!file) return;

      try {
        const text = await file.text();
        // Dùng hàm mới có games
        useAppStore.getState().importDataWithGames(text);
        alert('Import thành công! Đã tải lại games.');
        // Reload để cập nhật
        window.location.reload();
      } catch (error) {
        console.error('Import failed:', error);
        alert('Import thất bại: File không hợp lệ hoặc lỗi định dạng');
      }
    };
    input.click();
  };

  const handleClearData = () => {
    if (confirm('Are you sure? This will delete ALL your data and cannot be undone!')) {
      if (confirm('This is your FINAL warning. Continue?')) {
        storageService.clearAll();
        window.location.reload();
      }
    }
  };

  return (
    <div className="max-w-4xl">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-dark-900 dark:text-white mb-2">
          Settings
        </h1>
        <p className="text-dark-600 dark:text-dark-400">
          Customize your app experience
        </p>
      </div>

      <div className="space-y-6">
        {/* Appearance */}
        <Card className="p-6">
          <h2 className="text-xl font-semibold text-dark-900 dark:text-white mb-4 flex items-center gap-2">
            <Shield size={20} />
            Appearance
          </h2>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-dark-700 dark:text-dark-300 mb-2">
                Theme
              </label>
              <div className="flex gap-2">
                {['light', 'dark', 'system'].map((theme) => (
                  <button
                    key={theme}
                    onClick={() => updateSettings({ theme })}
                    className={`px-4 py-2 rounded-lg border-2 transition-all ${
                      settings.theme === theme
                        ? 'border-primary-600 bg-primary-50 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300'
                        : 'border-dark-300 dark:border-dark-600 hover:border-primary-400'
                    }`}
                  >
                    {theme.charAt(0).toUpperCase() + theme.slice(1)}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-dark-700 dark:text-dark-300 mb-2">
                Default View
              </label>
              <div className="flex gap-2">
                {['grid', 'list'].map((view) => (
                  <button
                    key={view}
                    onClick={() => updateSettings({ defaultView: view })}
                    className={`px-4 py-2 rounded-lg border-2 transition-all ${
                      settings.defaultView === view
                        ? 'border-primary-600 bg-primary-50 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300'
                        : 'border-dark-300 dark:border-dark-600 hover:border-primary-400'
                    }`}
                  >
                    {view.charAt(0).toUpperCase() + view.slice(1)}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </Card>

        {/* Security */}
        <Card className="p-6">
          <h2 className="text-xl font-semibold text-dark-900 dark:text-white mb-4 flex items-center gap-2">
            <Key size={20} />
            Security
          </h2>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-dark-900 dark:text-white">Auto Lock</p>
                <p className="text-sm text-dark-600 dark:text-dark-400">
                  Lock app after period of inactivity
                </p>
              </div>
              <button
                onClick={() => updateSettings({ autoLock: !settings.autoLock })}
                className={`relative w-12 h-6 rounded-full transition-colors ${
                  settings.autoLock ? 'bg-primary-600' : 'bg-dark-300 dark:bg-dark-600'
                }`}
              >
                <span
                  className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full transition-transform ${
                    settings.autoLock ? 'translate-x-6' : ''
                  }`}
                />
              </button>
            </div>

            {settings.autoLock && (
              <div>
                <label className="block text-sm font-medium text-dark-700 dark:text-dark-300 mb-2">
                  Auto Lock Timeout (minutes)
                </label>
                <input
                  type="number"
                  min="1"
                  max="120"
                  value={settings.autoLockTimeout}
                  onChange={(e) =>
                    updateSettings({ autoLockTimeout: parseInt(e.target.value) || 15 })
                  }
                  className="w-32 px-4 py-2 bg-white dark:bg-dark-700 border border-dark-300 dark:border-dark-600 rounded-lg"
                />
              </div>
            )}
          </div>
        </Card>

        {/* Notifications */}
        <Card className="p-6">
          <h2 className="text-xl font-semibold text-dark-900 dark:text-white mb-4 flex items-center gap-2">
            <Bell size={20} />
            Notifications
          </h2>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-dark-900 dark:text-white">
                  Show Notifications
                </p>
                <p className="text-sm text-dark-600 dark:text-dark-400">
                  Get notified about important events
                </p>
              </div>
              <button
                onClick={() =>
                  updateSettings({ showNotifications: !settings.showNotifications })
                }
                className={`relative w-12 h-6 rounded-full transition-colors ${
                  settings.showNotifications
                    ? 'bg-primary-600'
                    : 'bg-dark-300 dark:bg-dark-600'
                }`}
              >
                <span
                  className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full transition-transform ${
                    settings.showNotifications ? 'translate-x-6' : ''
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-dark-900 dark:text-white">
                  Minimize to Tray
                </p>
                <p className="text-sm text-dark-600 dark:text-dark-400">
                  Keep app running in system tray
                </p>
              </div>
              <button
                onClick={() =>
                  updateSettings({ minimizeToTray: !settings.minimizeToTray })
                }
                className={`relative w-12 h-6 rounded-full transition-colors ${
                  settings.minimizeToTray
                    ? 'bg-primary-600'
                    : 'bg-dark-300 dark:bg-dark-600'
                }`}
              >
                <span
                  className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full transition-transform ${
                    settings.minimizeToTray ? 'translate-x-6' : ''
                  }`}
                />
              </button>
            </div>
          </div>
        </Card>

        {/* Data Management */}
        <Card className="p-6">
          <h2 className="text-xl font-semibold text-dark-900 dark:text-white mb-4 flex items-center gap-2">
            <Download size={20} />
            Data Management
          </h2>

          <div className="space-y-3">
            <Button
              variant="secondary"
              icon={<Download size={18} />}
              onClick={handleExport}
              fullWidth
            >
              Export All Data
            </Button>

            <Button
              variant="secondary"
              icon={<Upload size={18} />}
              onClick={handleImport}
              fullWidth
            >
              Import Data
            </Button>

            <Button
              variant="danger"
              icon={<Trash2 size={18} />}
              onClick={handleClearData}
              fullWidth
            >
              Clear All Data (Dangerous!)
            </Button>
          </div>

          <div className="mt-4 p-3 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg">
            <p className="text-sm text-yellow-800 dark:text-yellow-200">
              <strong>Backup regularly!</strong> Export your data to keep a secure backup
              of your accounts.
            </p>
          </div>
        </Card>

        {/* App Info */}
        <Card className="p-6">
          <div className="text-center space-y-2">
            <p className="text-sm text-dark-600 dark:text-dark-400">
              Game Account Manager v1.0.0
            </p>
            <p className="text-xs text-dark-500 dark:text-dark-500">
              Built with Electron, React, and JavaScript
            </p>
            <p className="text-xs text-dark-500 dark:text-dark-500">
              Storage: {(storageService.getStoreSize() / 1024).toFixed(2)} KB
            </p>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default Settings;