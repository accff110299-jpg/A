import React from 'react';
import { useAppStore } from '../../store/useAppStore';
import { Plus, Trash2, Copy, Edit3, Search, Zap, Keyboard, Clock, ExternalLink } from 'lucide-react';
import { motion } from 'framer-motion';
import { Card } from '../components/Card';
import { Button } from '../components/Button';
import { QuickLoginService } from '../../core/services/QuickLoginService';

const AccountsList = () => {
  const { accounts, games, groups, addAccount, updateAccount, deleteAccount, addGame, accountService } = useAppStore();
  
  const [searchTerm, setSearchTerm] = React.useState('');
  const [filterGameId, setFilterGameId] = React.useState('');
  const [filterGroupId, setFilterGroupId] = React.useState('');
  const [showForm, setShowForm] = React.useState(false);
  const [editingAccount, setEditingAccount] = React.useState(null);
  const [deleteId, setDeleteId] = React.useState(null);
  const [showAddGame, setShowAddGame] = React.useState(false);
  const [newGameName, setNewGameName] = React.useState('');
  const [newGameUrl, setNewGameUrl] = React.useState('');

  const [form, setForm] = React.useState({
    username: '',
    password: '',
    email: '',
    gameId: '',
    groupId: '',
    notes: '',
  });

  // Quick Login Service
  const quickLogin = React.useRef(new QuickLoginService()).current;

  React.useEffect(() => {
    // Request notification permission on mount
    quickLogin.requestNotificationPermission();
  }, [quickLogin]);

  React.useEffect(() => {
    if (showForm) {
      if (editingAccount) {
        const decrypted = accountService.getDecryptedPassword(editingAccount);
        setForm({
          username: editingAccount.username || '',
          password: decrypted || '',
          email: editingAccount.email || '',
          gameId: editingAccount.gameId || '',
          groupId: editingAccount.groupId || '',
          notes: editingAccount.notes || '',
        });
      } else {
        setForm({ username: '', password: '', email: '', gameId: '', groupId: '', notes: '' });
      }
    }
  }, [showForm, editingAccount, accountService]);

  const filtered = accounts.filter(acc => {
    const matchSearch = (acc.username || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
                        (acc.notes || '').toLowerCase().includes(searchTerm.toLowerCase());
    const matchGame = filterGameId ? acc.gameId === filterGameId : true;
    const matchGroup = filterGroupId ? acc.groupId === filterGroupId : true;
    return matchSearch && matchGame && matchGroup;
  });

  const handleSave = () => {
    if (!form.username || !form.password) {
      alert('Username và Password là bắt buộc!');
      return;
    }
    if (editingAccount) {
      updateAccount(editingAccount.id, form);
    } else {
      addAccount(form);
    }
    setShowForm(false);
    setEditingAccount(null);
  };

  const handleAddGame = () => {
    if (newGameName.trim()) {
      addGame({ name: newGameName.trim(), url: newGameUrl.trim() });
      setNewGameName('');
      setNewGameUrl('');
      setShowAddGame(false);
    }
  };

  const copyText = (text) => {
    navigator.clipboard.writeText(text);
    quickLogin.showToast('Copied!', `${text.substring(0, 20)}...`, 'success', 2000);
  };

  // AUTO-LOGIN HANDLERS
  const handleQuickLogin = async (acc) => {
    const decrypted = accountService.getDecryptedPassword(acc);
    const game = games.find(g => g.id === acc.gameId);
    const gameUrl = game?.url;

    console.log('🎮 Quick Login:', { acc, game, gameUrl });

    if (gameUrl && gameUrl.trim()) {
      await quickLogin.sequentialCopy(acc.username, decrypted, gameUrl);
    } else {
      quickLogin.showToast(
        '⚠️ No URL',
        `Game "${game?.name || 'Unknown'}" has no URL. Add URL in Games Manager!`,
        'warning',
        4000
      );
      await quickLogin.sequentialCopy(acc.username, decrypted, null);
    }
  };

  // Thêm vào AccountsList.jsx để debug
// Trong handleSmartLaunch:

const handleSmartLaunch = async (acc) => {
  const decrypted = accountService.getDecryptedPassword(acc);
  const game = games.find(g => g.id === acc.gameId);
  const gameUrl = game?.url;

  console.log('🎮 Account:', acc);
  console.log('🎮 Game:', game);
  console.log('🎮 Game URL:', gameUrl);
  
  if (!gameUrl || gameUrl.trim() === '') {
    quickLogin.showToast(
      '⚠️ Thiếu URL!',
      `Game "${game?.name || 'Unknown'}" chưa có URL. Vào Games Manager để thêm URL!`,
      'warning',
      5000
    );
    await quickLogin.sequentialCopy(acc.username, decrypted, null);
    return;
  }

  // ✅ GỌI AUTO-TYPE
  await quickLogin.autoType(acc.username, decrypted, gameUrl, {
    launchDelay: 3000,       // Đợi 3s sau khi mở game
    formDelay: 20000,        // Đợi 20s cho form login load
    countdownSeconds: 5,     // Countdown 5s
    typingDelay: 1000,       // Delay giữa các lần gõ
  });
};

  const handleManualLaunch = async (acc) => {
    const game = games.find(g => g.id === acc.gameId);
    const gameUrl = game?.url;

    if (!gameUrl || gameUrl.trim() === '') {
      quickLogin.showToast('⚠️ No URL', 'Add URL in Games Manager first!', 'warning', 3000);
      return;
    }

    await quickLogin.launchGame(gameUrl);
  };
  

  const handleHotkeyMode = (acc) => {
    const decrypted = accountService.getDecryptedPassword(acc);
    const result = quickLogin.setupHotkeys(acc.username, decrypted);
    
    if (!result.success) {
      quickLogin.showToast(
        '⚠️ Electron Only',
        'Hotkeys only work in Electron app!',
        'warning',
        3000
      );
    }
  };

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">Quản lý Tài khoản</h1>
        
        <div className="flex gap-2">
          <Button 
            variant="secondary" 
            size="sm"
            icon={<Keyboard size={16} />}
            onClick={() => {
              quickLogin.showToast(
                'Keyboard Shortcuts',
                'Ctrl+Shift+U = Username | Ctrl+Shift+P = Password',
                'info',
                5000
              );
            }}
          >
            Shortcuts
          </Button>
        </div>
      </div>

      <div className="flex flex-wrap gap-4 mb-6">
        <div className="flex items-center border rounded-lg bg-white dark:bg-dark-700 px-3">
          <Search size={18} className="text-dark-400 mr-2" />
          <input
            type="text"
            placeholder="Tìm kiếm..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="py-2 outline-none bg-transparent"
          />
        </div>

        <select value={filterGameId} onChange={e => setFilterGameId(e.target.value)} className="px-4 py-2 border rounded-lg">
          <option value="">Tất cả game</option>
          {games.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
        </select>

        <select value={filterGroupId} onChange={e => setFilterGroupId(e.target.value)} className="px-4 py-2 border rounded-lg">
          <option value="">Tất cả nhóm</option>
          {groups.map(gr => <option key={gr.id} value={gr.id}>{gr.name}</option>)}
        </select>

        <Button icon={<Plus />} onClick={() => { setShowForm(true); setEditingAccount(null); }}>
          Thêm tài khoản
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
        {filtered.map(acc => {
          const game = games.find(g => g.id === acc.gameId);
          const group = groups.find(gr => gr.id === acc.groupId);
          const decrypted = accountService.getDecryptedPassword(acc);
          const hasGameUrl = game?.url && game.url.trim() !== '';

          return (
            <motion.div key={acc.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <Card className="p-5 hoverable">
                <div className="flex justify-between mb-3">
                  <div className="flex-1">
                    <h3 className="font-bold text-lg">{acc.username || 'Unnamed'}</h3>
                    {!hasGameUrl && game && (
                      <p className="text-xs text-yellow-600 dark:text-yellow-400 mt-1">
                        ⚠️ No URL - add in Games Manager
                      </p>
                    )}
                  </div>
                  <Button size="sm" variant="ghost" onClick={() => setDeleteId(acc.id)}>
                    <Trash2 size={16} />
                  </Button>
                </div>

                <div className="space-y-1 mb-4">
                  <p className="text-sm text-dark-600 dark:text-dark-400 flex items-center gap-2">
                    Game: {game?.name || 'N/A'}
                    {hasGameUrl && (
                      <button 
                        onClick={() => handleManualLaunch(acc)}
                        className="text-primary-600 hover:text-primary-700"
                      >
                        <ExternalLink size={14} />
                      </button>
                    )}
                  </p>
                  {group && <p className="text-sm text-dark-600 dark:text-dark-400">Nhóm: {group.name}</p>}
                  {acc.notes && <p className="text-xs text-dark-500 dark:text-dark-500 mt-2 line-clamp-2">{acc.notes}</p>}
                </div>

                {/* AUTO-LOGIN BUTTONS */}
                <div className="space-y-2">
                  {hasGameUrl ? (
                    <Button 
                      size="sm" 
                      fullWidth 
                      onClick={() => handleSmartLaunch(acc)}
                      icon={<Zap size={16} />}
                    >
                      🚀 Smart Launch
                    </Button>
                  ) : (
                    <Button 
                      size="sm" 
                      fullWidth 
                      variant="secondary"
                      onClick={() => handleQuickLogin(acc)}
                      icon={<Copy size={16} />}
                    >
                      📋 Copy Credentials
                    </Button>
                  )}

                  <div className="grid grid-cols-3 gap-2">
                    <Button 
                      size="sm" 
                      variant="secondary"
                      onClick={() => handleQuickLogin(acc)}
                      icon={<Clock size={14} />}
                    >
                      Quick
                    </Button>
                    
                    <Button 
                      size="sm" 
                      variant="secondary"
                      onClick={() => copyText(acc.username)}
                      icon={<Copy size={14} />}
                    >
                      User
                    </Button>
                    
                    <Button 
                      size="sm" 
                      variant="secondary"
                      onClick={() => copyText(decrypted)}
                      icon={<Copy size={14} />}
                    >
                      Pass
                    </Button>
                  </div>
                </div>

                <Button 
                  variant="ghost" 
                  fullWidth 
                  className="mt-3" 
                  onClick={() => { setEditingAccount(acc); setShowForm(true); }}
                >
                  <Edit3 size={16} className="mr-1" /> Sửa
                </Button>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-12">
          <p className="text-dark-500 dark:text-dark-400">Không tìm thấy tài khoản nào</p>
        </div>
      )}

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-xl p-6 max-h-[90vh] overflow-y-auto">
            <h2 className="text-2xl font-bold mb-5">{editingAccount ? 'Sửa tài khoản' : 'Thêm tài khoản mới'}</h2>
            <div className="space-y-4">
              <input 
                className="w-full px-4 py-2 border rounded-lg dark:bg-dark-700 dark:border-dark-600" 
                placeholder="Username *" 
                value={form.username} 
                onChange={e => setForm({...form, username: e.target.value})} 
              />
              <input 
                className="w-full px-4 py-2 border rounded-lg dark:bg-dark-700 dark:border-dark-600" 
                type="password" 
                placeholder="Password *" 
                value={form.password} 
                onChange={e => setForm({...form, password: e.target.value})} 
              />
              <input 
                className="w-full px-4 py-2 border rounded-lg dark:bg-dark-700 dark:border-dark-600" 
                placeholder="Email (tùy chọn)" 
                value={form.email} 
                onChange={e => setForm({...form, email: e.target.value})} 
              />

              <div>
                <select 
                  className="w-full px-4 py-2 border rounded-lg mb-2 dark:bg-dark-700 dark:border-dark-600" 
                  value={form.gameId} 
                  onChange={e => setForm({...form, gameId: e.target.value})}
                >
                  <option value="">Chọn game</option>
                  {games.map(g => (
                    <option key={g.id} value={g.id}>
                      {g.name} {g.url ? '✓' : '⚠️ No URL'}
                    </option>
                  ))}
                </select>
                <Button size="sm" variant="ghost" onClick={() => setShowAddGame(true)}>+ Thêm game mới</Button>
                {showAddGame && (
                  <div className="mt-3 space-y-2 p-3 bg-dark-50 dark:bg-dark-700 rounded-lg">
                    <input 
                      className="w-full px-3 py-2 border rounded dark:bg-dark-800" 
                      placeholder="Tên game" 
                      value={newGameName} 
                      onChange={e => setNewGameName(e.target.value)} 
                    />
                    <input 
                      className="w-full px-3 py-2 border rounded dark:bg-dark-800" 
                      placeholder="URL (e.g., https://game.com)" 
                      value={newGameUrl} 
                      onChange={e => setNewGameUrl(e.target.value)} 
                    />
                    <Button size="sm" onClick={handleAddGame}>Thêm game</Button>
                  </div>
                )}
              </div>

              <select 
                className="w-full px-4 py-2 border rounded-lg dark:bg-dark-700 dark:border-dark-600" 
                value={form.groupId} 
                onChange={e => setForm({...form, groupId: e.target.value})}
              >
                <option value="">Không nhóm</option>
                {groups.map(gr => <option key={gr.id} value={gr.id}>{gr.name}</option>)}
              </select>

              <textarea 
                className="w-full px-4 py-2 border rounded-lg dark:bg-dark-700 dark:border-dark-600" 
                rows={3} 
                placeholder="Ghi chú" 
                value={form.notes} 
                onChange={e => setForm({...form, notes: e.target.value})} 
              />

              <div className="flex gap-3">
                <Button onClick={handleSave} fullWidth>{editingAccount ? 'Cập nhật' : 'Thêm'}</Button>
                <Button variant="secondary" onClick={() => { setShowForm(false); setShowAddGame(false); }} fullWidth>Hủy</Button>
              </div>
            </div>
          </Card>
        </div>
      )}

      {/* Delete Confirm */}
      {deleteId && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50">
          <Card className="p-6">
            <h3 className="text-xl font-bold mb-4">Xóa tài khoản?</h3>
            <div className="flex gap-3">
              <Button variant="danger" onClick={() => { deleteAccount(deleteId); setDeleteId(null); }}>Xóa</Button>
              <Button variant="secondary" onClick={() => setDeleteId(null)}>Hủy</Button>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
  
};

export default AccountsList;