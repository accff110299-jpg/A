import React from 'react';
import { useAppStore } from '../../store/useAppStore';
import { Plus, Edit3, Trash2, ExternalLink } from 'lucide-react';
import { Card } from '../components/Card';
import { Button } from '../components/Button';

const GamesManager = () => {
  const { games, addGame, updateGame, deleteGame } = useAppStore();
  const [name, setName] = React.useState('');
  const [url, setUrl] = React.useState('');
  const [editing, setEditing] = React.useState(null);
  const [deleteId, setDeleteId] = React.useState(null);

  const handleSave = () => {
    if (!name.trim()) {
      alert('Tên game không được để trống!');
      return;
    }
    if (editing) {
      updateGame(editing.id, { name: name.trim(), url: url.trim() });
      setEditing(null);
    } else {
      addGame({ name: name.trim(), url: url.trim() });
    }
    setName('');
    setUrl('');
  };

  const handleEdit = (game) => {
    setEditing(game);
    setName(game.name);
    setUrl(game.url || '');
  };

  const handleCancel = () => {
    setEditing(null);
    setName('');
    setUrl('');
  };

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Quản lý Games</h1>

      <Card className="p-6 mb-6">
        <div className="space-y-3">
          <input
            className="w-full px-4 py-2 border rounded-lg"
            placeholder="Tên game"
            value={name}
            onChange={e => setName(e.target.value)}
          />
          <input
            className="w-full px-4 py-2 border rounded-lg"
            placeholder="URL (tùy chọn)"
            value={url}
            onChange={e => setUrl(e.target.value)}
          />
          <div className="flex gap-3">
            <Button icon={editing ? <Edit3 size={18} /> : <Plus />} onClick={handleSave}>
              {editing ? 'Cập nhật' : 'Thêm game'}
            </Button>
            {editing && (
              <Button variant="secondary" onClick={handleCancel}>
                Hủy
              </Button>
            )}
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {games.length === 0 ? (
          <p className="text-dark-600 dark:text-dark-400 col-span-full text-center py-8">
            Chưa có game nào. Thêm game đầu tiên ở trên!
          </p>
        ) : (
          games.map(game => (
            <Card key={game.id} className="p-5">
              <div className="flex justify-between items-start mb-3">
                <div className="flex-1">
                  <h3 className="font-bold text-xl">{game.name}</h3>
                  {game.url && (
                    <a 
                      href={game.url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-sm text-primary-600 dark:text-primary-400 hover:underline flex items-center gap-1 mt-1"
                    >
                      <ExternalLink size={14} />
                      Mở link
                    </a>
                  )}
                </div>
                <Button size="sm" variant="ghost" onClick={() => setDeleteId(game.id)}>
                  <Trash2 size={16} />
                </Button>
              </div>
              <div className="flex gap-2">
                <Button fullWidth onClick={() => handleEdit(game)}>
                  Sửa
                </Button>
              </div>
            </Card>
          ))
        )}
      </div>

      {deleteId && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50">
          <Card className="p-6">
            <h3 className="text-xl font-bold mb-4">Xóa game?</h3>
            <p className="mb-4">Tài khoản liên kết với game này sẽ mất thông tin game.</p>
            <div className="flex gap-3">
              <Button variant="danger" onClick={() => { deleteGame(deleteId); setDeleteId(null); }}>
                Xóa
              </Button>
              <Button variant="secondary" onClick={() => setDeleteId(null)}>
                Hủy
              </Button>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
};

export default GamesManager;