import React from 'react';
import { useAppStore } from '../../store/useAppStore';
import { Plus, Edit3, Trash2 } from 'lucide-react';
import { Card } from '../components/Card';
import { Button } from '../components/Button';

const GroupsManager = () => {
  const { groups, addGroup, updateGroup, deleteGroup } = useAppStore();
  const [name, setName] = React.useState('');
  const [editing, setEditing] = React.useState(null);
  const [deleteId, setDeleteId] = React.useState(null);

  const handleSave = () => {
    if (!name.trim()) return alert('Tên nhóm không được để trống!');
    if (editing) {
      updateGroup(editing.id, { name: name.trim() });
      setEditing(null);
    } else {
      addGroup({ name: name.trim() });
    }
    setName('');
  };

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Quản lý Nhóm</h1>

      <Card className="p-6 mb-6">
        <div className="flex gap-3">
          <input className="flex-1 px-4 py-2 border rounded-lg" placeholder="Tên nhóm mới" value={name} onChange={e => setName(e.target.value)} />
          <Button icon={editing ? <Edit3 size={18} /> : <Plus />} onClick={handleSave}>
            {editing ? 'Cập nhật' : 'Thêm nhóm'}
          </Button>
          {editing && <Button variant="secondary" onClick={() => { setEditing(null); setName(''); }}>Hủy</Button>}
        </div>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {groups.map(gr => (
          <Card key={gr.id} className="p-5">
            <div className="flex justify-between items-start mb-3">
              <h3 className="font-bold text-xl">{gr.name}</h3>
              <Button size="sm" variant="ghost" onClick={() => setDeleteId(gr.id)}>
                <Trash2 size={16} />
              </Button>
            </div>
            <div className="flex gap-2">
              <Button fullWidth onClick={() => { setEditing(gr); setName(gr.name); }}>
                Sửa tên
              </Button>
            </div>
          </Card>
        ))}
      </div>

      {deleteId && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50">
          <Card className="p-6">
            <h3 className="text-xl font-bold mb-4">Xóa nhóm?</h3>
            <p className="mb-4">Tài khoản thuộc nhóm sẽ mất liên kết.</p>
            <div className="flex gap-3">
              <Button variant="danger" onClick={() => { deleteGroup(deleteId); setDeleteId(null); }}>Xóa</Button>
              <Button variant="secondary" onClick={() => setDeleteId(null)}>Hủy</Button>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
};

export default GroupsManager;