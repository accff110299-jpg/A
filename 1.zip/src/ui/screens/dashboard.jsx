import React from 'react';
import { motion } from 'framer-motion';
import {
  TrendingUp,
  Users,
  Clock,
  Star,
  Plus,
  Grid,
  List,
  Search,
} from 'lucide-react';
import { useAppStore } from '../../store/useAppStore';
import { Card } from '../components/Card';
import { Button } from '../components/Button';
import { Input } from '../components/Input';
import { AccountCard } from '../components/AccountCard';

 const Dashboard = () => {
  const {
    accounts,
    viewMode,
    filter,
    setViewMode,
    setFilter,
    markAccountAsUsed,
    toggleFavorite,
    accountService,
  } = useAppStore();

  const [searchTerm, setSearchTerm] = React.useState('');

  // Filter accounts based on search
  const filteredAccounts = React.useMemo(() => {
    return accountService.filterAndSortAccounts(accounts, {
      ...filter,
      searchTerm,
    });
  }, [accounts, filter, searchTerm, accountService]);

  // Get stats
  const stats = React.useMemo(() => {
    return accountService.getStats(accounts);
  }, [accounts, accountService]);

  const handleLaunch = (account) => {
    // TODO: Implement actual launch logic
    markAccountAsUsed(account.id);
    console.log('Launching account:', account.name);
  };

  const handleEdit = (account) => {
    // TODO: Open edit modal
    console.log('Edit account:', account.id);
  };

  const handleDelete = (account) => {
    // TODO: Show confirmation dialog
    console.log('Delete account:', account.id);
  };

  const handleToggleFavorite = (account) => {
    toggleFavorite(account.id);
  };

  const handleCopyPassword = async (account) => {
    try {
      const password = accountService.getDecryptedPassword(account);
      await navigator.clipboard.writeText(password);
      // TODO: Show success toast
      console.log('Password copied!');
    } catch (error) {
      console.error('Failed to copy password:', error);
      // TODO: Show error toast
    }
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-dark-900 dark:text-white mb-2">
          Dashboard
        </h1>
        <p className="text-dark-600 dark:text-dark-400">
          Welcome back! Manage your game accounts here.
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-primary-100 dark:bg-primary-900/30 rounded-lg">
              <Users className="text-primary-600 dark:text-primary-400" size={24} />
            </div>
            <div>
              <p className="text-sm text-dark-600 dark:text-dark-400">
                Total Accounts
              </p>
              <p className="text-2xl font-bold text-dark-900 dark:text-white">
                {stats.totalAccounts}
              </p>
            </div>
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-yellow-100 dark:bg-yellow-900/30 rounded-lg">
              <Star className="text-yellow-600 dark:text-yellow-400" size={24} />
            </div>
            <div>
              <p className="text-sm text-dark-600 dark:text-dark-400">Favorites</p>
              <p className="text-2xl font-bold text-dark-900 dark:text-white">
                {accounts.filter((a) => a.isFavorite).length}
              </p>
            </div>
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-green-100 dark:bg-green-900/30 rounded-lg">
              <TrendingUp className="text-green-600 dark:text-green-400" size={24} />
            </div>
            <div>
              <p className="text-sm text-dark-600 dark:text-dark-400">Most Used</p>
              <p className="text-lg font-bold text-dark-900 dark:text-white truncate">
                {stats.mostUsed[0]?.name || 'N/A'}
              </p>
            </div>
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
              <Clock className="text-blue-600 dark:text-blue-400" size={24} />
            </div>
            <div>
              <p className="text-sm text-dark-600 dark:text-dark-400">
                Recently Used
              </p>
              <p className="text-lg font-bold text-dark-900 dark:text-white truncate">
                {stats.recentlyUsed[0]?.name || 'N/A'}
              </p>
            </div>
          </div>
        </Card>
      </div>

      {/* Toolbar */}
      <div className="flex items-center gap-3 mb-6">
        <div className="flex-1">
          <Input
            placeholder="Search accounts..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            icon={<Search size={18} />}
          />
        </div>

        <div className="flex items-center gap-2 bg-white dark:bg-dark-800 rounded-lg border border-dark-200 dark:border-dark-700 p-1">
          <button
            onClick={() => setViewMode('grid')}
            className={`p-2 rounded transition-colors ${
              viewMode === 'grid'
                ? 'bg-primary-100 dark:bg-primary-900/30 text-primary-600 dark:text-primary-400'
                : 'text-dark-600 dark:text-dark-400 hover:bg-dark-100 dark:hover:bg-dark-700'
            }`}
          >
            <Grid size={18} />
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={`p-2 rounded transition-colors ${
              viewMode === 'list'
                ? 'bg-primary-100 dark:bg-primary-900/30 text-primary-600 dark:text-primary-400'
                : 'text-dark-600 dark:text-dark-400 hover:bg-dark-100 dark:hover:bg-dark-700'
            }`}
          >
            <List size={18} />
          </button>
        </div>

        <Button icon={<Plus size={18} />} onClick={() => console.log('Add account')}>
          Add Account
        </Button>
      </div>

      {/* Accounts Grid/List */}
      {filteredAccounts.length === 0 ? (
        <Card className="p-12 text-center">
          <div className="flex flex-col items-center gap-4">
            <div className="p-4 bg-dark-100 dark:bg-dark-800 rounded-full">
              <Users size={48} className="text-dark-400" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-dark-900 dark:text-white mb-1">
                No accounts found
              </h3>
              <p className="text-dark-600 dark:text-dark-400">
                {searchTerm
                  ? 'Try adjusting your search'
                  : 'Get started by adding your first account'}
              </p>
            </div>
            {!searchTerm && (
              <Button
                icon={<Plus size={18} />}
                onClick={() => console.log('Add account')}
              >
                Add Your First Account
              </Button>
            )}
          </div>
        </Card>
      ) : (
        <div
          className={
            viewMode === 'grid'
              ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4'
              : 'flex flex-col gap-3'
          }
        >
          {filteredAccounts.map((account, index) => (
            <motion.div
              key={account.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <AccountCard
                account={account}
                viewMode={viewMode}
                onLaunch={handleLaunch}
                onEdit={handleEdit}
                onDelete={handleDelete}
                onToggleFavorite={handleToggleFavorite}
                onCopyPassword={handleCopyPassword}
              />
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
};
export default Dashboard;